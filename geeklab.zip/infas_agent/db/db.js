const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const DB_PATH = path.join(__dirname, "geeklab.sqlite3");
const SCHEMA_PATH = path.join(__dirname, "schema.sql");

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// Apply schema on boot (idempotent — every statement uses IF NOT EXISTS).
const schema = fs.readFileSync(SCHEMA_PATH, "utf8");
db.exec(schema);

// Migration légère : si une base existante (créée avant l'ajout des champs
// jury/antenne/numéro de mémoire) ne contient pas encore ces colonnes,
// on les ajoute une par une. "CREATE TABLE IF NOT EXISTS" ne modifie jamais
// une table déjà existante, donc cette étape est nécessaire pour les bases
// déployées avant cette mise à jour.
const NEW_MEMOIRE_COLUMNS = [
  "co_director_name TEXT",
  "president_jury TEXT",
  "assesseur1 TEXT",
  "assesseur2 TEXT",
  "pays TEXT",
  "antenne TEXT",
  "ville TEXT",
  "antenne_code TEXT",
  "filiere TEXT",
  "filiere_code TEXT",
  "niveau TEXT",
  "numero_ordre TEXT",
  "soutenance_year TEXT",
  "soutenance_date TEXT",
];
for (const columnDef of NEW_MEMOIRE_COLUMNS) {
  try {
    db.exec(`ALTER TABLE memoires ADD COLUMN ${columnDef}`);
  } catch (err) {
    if (!/duplicate column name/i.test(err.message)) throw err;
  }
}

module.exports = db;

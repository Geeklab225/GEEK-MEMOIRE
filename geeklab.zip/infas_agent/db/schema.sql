-- Schema for INFAS Memoire Agent
-- Multi-user: each INFAS student has an account and can generate/manage
-- several memoire drafts.

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name     TEXT NOT NULL,
  institution   TEXT DEFAULT 'INFAS',
  antenne       TEXT,             -- ex: "Antenne d'Abengourou"
  filiere       TEXT,             -- ex: "Infirmier(ère)", "Sage-femme"
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS memoires (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id           INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  theme             TEXT NOT NULL,
  student_names     TEXT,             -- comma-separated, supports group memoires
  director_name     TEXT,
  co_director_name  TEXT,             -- Co-Directeur de mémoire (page de garde, slide 12)
  president_jury    TEXT,             -- Président du jury (page de garde, slide 12)
  assesseur1        TEXT,             -- Assesseur 1 (page de garde, slide 12)
  assesseur2        TEXT,             -- Assesseur 2 (page de garde, slide 12)
  academic_year     TEXT,
  pays              TEXT,             -- Pays (page de garde, slide 11)
  antenne           TEXT,             -- Antenne / structure de stage
  ville             TEXT,             -- Ville de soutenance (si différente de l'antenne)
  antenne_code      TEXT,             -- Code antenne pour le numéro de mémoire (ex: ABG) — slide 13
  filiere           TEXT,
  filiere_code      TEXT,             -- Code filière pour le numéro de mémoire (ex: SFM, IDE) — slide 13
  niveau            TEXT,             -- ex: IDE3, SFM3 — pied de page (slide 48)
  numero_ordre      TEXT,             -- Numéro d'ordre (page de garde, slide 13)
  soutenance_year   TEXT,             -- Année de soutenance (page de garde, slide 13)
  soutenance_date   TEXT,             -- Date de soutenance (page de garde, slide 11)
  status            TEXT NOT NULL DEFAULT 'draft',  -- draft | generating | ready | error
  structure_version TEXT,             -- which methodology structure was used
  content_json      TEXT,             -- generated section content, as JSON
  docx_path         TEXT,             -- path to generated .docx once ready
  error_message     TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_memoires_user ON memoires(user_id);

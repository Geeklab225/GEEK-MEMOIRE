require("dotenv").config();

const express = require("express");
const session = require("express-session");
const path = require("path");

require("./db/db"); // applies schema on boot

const authRoutes = require("./routes/auth");
const memoiresRoutes = require("./routes/memoires");

const app = express();
const PORT = process.env.PORT || 3000;
const IS_PRODUCTION = process.env.NODE_ENV === "production";

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Nécessaire derrière un reverse proxy TLS (Railway, Render, Nginx…) pour que
// express-session détecte correctement une requête HTTPS et pose le cookie
// "secure" à bon escient.
if (IS_PRODUCTION) app.set("trust proxy", 1);

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.use(
  session({
    secret: process.env.SESSION_SECRET || "geeklab-dev-secret-change-me",
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24 * 7, // 7 jours
      secure: IS_PRODUCTION, // cookie envoyé uniquement en HTTPS en production
    },
  })
);

app.get("/", (req, res) => res.redirect(req.session.userId ? "/dashboard" : "/login"));

app.use(authRoutes);
app.use(memoiresRoutes);

app.use((req, res) => res.status(404).send("Page introuvable."));

app.listen(PORT, () => {
  console.log(`GEEKLAB en écoute sur http://localhost:${PORT}`);
});

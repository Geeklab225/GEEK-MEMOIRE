const express = require("express");
const fs = require("fs");
const path = require("path");
const db = require("../db/db");
const { generateMemoire } = require("../generator/pipeline");
const { hasApiKey } = require("../generator/llm");
const { ANTENNE_CODES } = require("../generator/antennes");

const router = express.Router();
const GENERATED_DIR = path.join(__dirname, "..", "generated");
if (!fs.existsSync(GENERATED_DIR)) fs.mkdirSync(GENERATED_DIR, { recursive: true });

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.redirect("/login");
  next();
}

router.get("/dashboard", requireAuth, (req, res) => {
  const memoires = db
    .prepare("SELECT * FROM memoires WHERE user_id = ? ORDER BY created_at DESC")
    .all(req.session.userId);
  res.render("dashboard", { memoires, fullName: req.session.fullName, hasApiKey });
});

router.get("/memoires/new", requireAuth, (req, res) => {
  res.render("new-memoire", { error: null, antenneCodes: ANTENNE_CODES });
});

router.post("/memoires", requireAuth, async (req, res) => {
  const {
    theme, student_names, director_name, co_director_name,
    president_jury, assesseur1, assesseur2,
    academic_year, pays, antenne, ville, antenne_code,
    filiere, filiere_code, niveau, numero_ordre,
    soutenance_year, soutenance_date,
  } = req.body;

  if (!theme || theme.trim().length < 8) {
    return res.render("new-memoire", { error: "Merci de préciser un thème (au moins quelques mots).", antenneCodes: ANTENNE_CODES });
  }

  const info = db
    .prepare(
      `INSERT INTO memoires (
         user_id, theme, student_names, director_name, co_director_name,
         president_jury, assesseur1, assesseur2, academic_year, pays,
         antenne, ville, antenne_code, filiere, filiere_code, niveau,
         numero_ordre, soutenance_year, soutenance_date, status
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'generating')`
    )
    .run(
      req.session.userId, theme.trim(), student_names || null, director_name || null, co_director_name || null,
      president_jury || null, assesseur1 || null, assesseur2 || null, academic_year || null, pays || null,
      antenne || null, ville || null, antenne_code || null, filiere || null, filiere_code || null, niveau || null,
      numero_ordre || null, soutenance_year || null, soutenance_date || null
    );

  const memoireId = info.lastInsertRowid;
  res.redirect(`/memoires/${memoireId}`);

  // Génération en arrière-plan (le formulaire ne bloque pas l'utilisateur).
  try {
    const { content, buffer } = await generateMemoire({
      theme: theme.trim(),
      studentNames: student_names,
      directorName: director_name,
      coDirectorName: co_director_name,
      presidentJury: president_jury,
      assesseur1,
      assesseur2,
      academicYear: academic_year,
      pays,
      antenne,
      ville,
      antenneCode: antenne_code,
      filiere,
      filiereCode: filiere_code,
      niveau,
      numeroOrdre: numero_ordre,
      soutenanceYear: soutenance_year,
      soutenanceDate: soutenance_date,
    });

    const fileName = `memoire-${memoireId}.docx`;
    fs.writeFileSync(path.join(GENERATED_DIR, fileName), buffer);

    db.prepare(
      `UPDATE memoires SET status = 'ready', content_json = ?, docx_path = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(JSON.stringify(content), fileName, memoireId);
  } catch (err) {
    db.prepare(
      `UPDATE memoires SET status = 'error', error_message = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(String(err.message || err), memoireId);
  }
});

router.get("/memoires/:id", requireAuth, (req, res) => {
  const memoire = db
    .prepare("SELECT * FROM memoires WHERE id = ? AND user_id = ?")
    .get(req.params.id, req.session.userId);
  if (!memoire) return res.status(404).send("Mémoire introuvable.");
  res.render("memoire-detail", { memoire, hasApiKey });
});

router.get("/memoires/:id/download", requireAuth, (req, res) => {
  const memoire = db
    .prepare("SELECT * FROM memoires WHERE id = ? AND user_id = ?")
    .get(req.params.id, req.session.userId);
  if (!memoire || !memoire.docx_path) return res.status(404).send("Fichier introuvable.");
  const filePath = path.join(GENERATED_DIR, memoire.docx_path);
  res.download(filePath, `${memoire.theme.slice(0, 60).replace(/[^\w\- ]/g, "")}.docx`);
});

module.exports = router;

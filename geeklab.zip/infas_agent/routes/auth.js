const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../db/db");

const router = express.Router();

function requireGuest(req, res, next) {
  if (req.session.userId) return res.redirect("/dashboard");
  next();
}

router.get("/register", requireGuest, (req, res) => {
  res.render("register", { error: null });
});

router.post("/register", requireGuest, (req, res) => {
  const { full_name, email, password, antenne, filiere } = req.body;

  if (!full_name || !email || !password) {
    return res.render("register", { error: "Tous les champs obligatoires doivent être remplis." });
  }
  if (password.length < 6) {
    return res.render("register", { error: "Le mot de passe doit contenir au moins 6 caractères." });
  }

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email.toLowerCase().trim());
  if (existing) {
    return res.render("register", { error: "Un compte existe déjà avec cet email." });
  }

  const password_hash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare(
      "INSERT INTO users (email, password_hash, full_name, antenne, filiere) VALUES (?, ?, ?, ?, ?)"
    )
    .run(email.toLowerCase().trim(), password_hash, full_name.trim(), antenne || null, filiere || null);

  req.session.userId = info.lastInsertRowid;
  req.session.fullName = full_name.trim();
  res.redirect("/dashboard");
});

router.get("/login", requireGuest, (req, res) => {
  res.render("login", { error: null });
});

router.post("/login", requireGuest, (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get((email || "").toLowerCase().trim());

  if (!user || !bcrypt.compareSync(password || "", user.password_hash)) {
    return res.render("login", { error: "Email ou mot de passe incorrect." });
  }

  req.session.userId = user.id;
  req.session.fullName = user.full_name;
  res.redirect("/dashboard");
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/login"));
});

module.exports = router;

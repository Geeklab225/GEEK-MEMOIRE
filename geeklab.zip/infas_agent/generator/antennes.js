/**
 * Table des codes d'antenne INFAS, telle que fournie dans le support
 * méthodologique officiel (slide 13), utilisée pour construire le "Numéro
 * de mémoire" imprimé sur la page de garde (ex: "N° 017SFM-26ABG").
 */
const ANTENNE_CODES = {
  ABENGOUROU: "ABG",
  ABIDJAN: "ABJ",
  ABOISSO: "ABO",
  AGBOVILLE: "AGB",
  BOUAKE: "BKE",
  DALOA: "DAL",
  MAN: "MAN",
  KORHOGO: "KGO",
};

function guessAntenneCode(villeOrAntenne) {
  if (!villeOrAntenne) return null;
  const normalized = String(villeOrAntenne)
    .toUpperCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, ""); // retire les accents
  for (const [ville, code] of Object.entries(ANTENNE_CODES)) {
    if (normalized.includes(ville)) return code;
  }
  return null;
}

/**
 * Construit le numéro de mémoire au format imposé par l'INFAS :
 * "N° <numéro d'ordre><code filière>-<année sur 2 chiffres><code antenne>"
 * Exemple donné par le guide : N° 017SFM-26ABG
 *
 * Si l'un des éléments manque, le champ correspondant est remplacé par un
 * espace réservé "?" plutôt que d'inventer une valeur.
 */
function buildNumeroMemoire(meta) {
  if (meta.numeroMemoire) return meta.numeroMemoire; // valeur déjà fournie explicitement

  const ordre = meta.numeroOrdre ? String(meta.numeroOrdre).padStart(3, "0") : "???";
  const filiereCode = (meta.filiereCode || "").toUpperCase() || "??";

  let yy = "??";
  const yearSource = meta.soutenanceYear || meta.academicYear;
  if (yearSource) {
    const match = String(yearSource).match(/(\d{4})/g);
    if (match && match.length) {
      const lastYear = match[match.length - 1];
      yy = lastYear.slice(-2);
    } else if (/^\d{2}$/.test(String(yearSource).trim())) {
      yy = String(yearSource).trim();
    }
  }

  const antenneCode = (meta.antenneCode || guessAntenneCode(meta.antenne) || guessAntenneCode(meta.ville) || "???").toUpperCase();

  return `N° ${ordre}${filiereCode}-${yy}${antenneCode}`;
}

module.exports = { ANTENNE_CODES, guessAntenneCode, buildNumeroMemoire };

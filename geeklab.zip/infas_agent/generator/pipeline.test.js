/**
 * Test d'intégration du pipeline complet (recherche → génération → .docx),
 * avec le réseau simulé (mêmes fixtures que research.test.js) et sans clé
 * API IA (mode "espace réservé"). Vérifie que :
 *  - la bibliographie du document est bien remplie à partir des sources
 *    réellement trouvées (pas vide, pas inventée), triée alphabétiquement
 *    ("alpha-numérique", exigence INFAS) et SANS numéro entre crochets ;
 *  - les sections marquées needsCitations reçoivent bien le bloc de
 *    sources dans leur prompt (visible ici dans le texte-espace-réservé),
 *    avec des citations au format Auteur-Année ;
 *  - le document se construit avec les nouvelles métadonnées (jury, numéro
 *    de mémoire, dédicaces, etc.) sans erreur.
 *
 * Lancer avec : node generator/pipeline.test.js
 */

const assert = require("assert");
const fs = require("fs");

const FIXTURES = {
  "esearch.fcgi": { esearchresult: { idlist: ["111"] } },
  "esummary.fcgi": {
    result: {
      "111": {
        uid: "111",
        title: "Knowledge and practice of nurses on the topic under study.",
        authors: [{ name: "Aneke JC" }],
        fulljournalname: "Journal of Nursing Research",
        pubdate: "2019",
        articleids: [{ idtype: "doi", value: "10.1234/test.111" }],
      },
    },
  },
  "api.crossref.org": {
    message: {
      items: [
        {
          title: ["A cross-sectional survey on the topic under study"],
          author: [{ given: "M", family: "Diallo" }],
          "container-title": ["African Journal of Nursing"],
          published: { "date-parts": [[2021]] },
          DOI: "10.1234/test.222",
          URL: "https://doi.org/10.1234/test.222",
        },
      ],
    },
  },
  "api.openalex.org": { results: [] },
};

global.fetch = async (url) => {
  const match = Object.keys(FIXTURES).find((key) => url.includes(key));
  if (!match) throw new Error(`Aucune fixture pour l'URL : ${url}`);
  return { ok: true, status: 200, json: async () => FIXTURES[match] };
};

const { generateMemoire } = require("./pipeline");

(async () => {
  const { content, buffer, sourcesFound, whoSheetFound } = await generateMemoire({
    theme: "Connaissances, attitudes et pratiques des infirmiers relatives à la transfusion sanguine",
    studentNames: "KOUAME Awa, TRAORE Ibrahim",
    directorName: "Dr Test",
    coDirectorName: "Dr Co-Test",
    presidentJury: "Pr Jury Président",
    assesseur1: "M. Assesseur Un",
    assesseur2: "Mme Assesseur Deux",
    antenne: "Abengourou",
    ville: "Abengourou",
    filiere: "Infirmier(ère)",
    filiereCode: "IDE",
    niveau: "IDE3",
    numeroOrdre: "17",
    academicYear: "2025-2026",
    soutenanceYear: "2026",
  });

  assert.ok(sourcesFound >= 2, `attendu au moins 2 sources trouvées, obtenu ${sourcesFound}`);
  assert.strictEqual(whoSheetFound, true, "la fiche OMS transfusion sanguine devrait être détectée");
  console.log(`✓ ${sourcesFound} sources trouvées, fiche OMS détectée : ${whoSheetFound}`);

  assert.ok(Array.isArray(content.references) && content.references.length >= 3, "la bibliographie doit contenir OMS + les 2 sources trouvées");
  content.references.forEach((r) => assert.ok(!/\[\d+\]/.test(r), `la référence ne doit PAS contenir de numéro entre crochets (règle INFAS) : ${r}`));
  console.log("✓ Bibliographie remplie automatiquement, sans numéro entre crochets :");
  content.references.forEach((r, i) => console.log(`    ${i + 1}. ${r}`));

  // Tri alphabétique attendu : Aneke (A), Diallo (D), Organisation mondiale... (O)
  const firstWords = content.references.map((r) => r[0]);
  const sortedCopy = [...firstWords].sort((a, b) => a.localeCompare(b, "fr"));
  assert.deepStrictEqual(firstWords, sortedCopy, "la bibliographie doit être triée alphabétiquement (méthode alpha-numérique INFAS)");
  console.log("✓ La bibliographie est bien triée alphabétiquement");

  const introText = content.enonce_probleme;
  assert.ok(introText.includes("Voici des sources réelles vérifiées"), "le prompt de l'énoncé du problème doit recevoir le bloc de sources");
  assert.ok(introText.includes("Aneke"), "le bloc de sources doit lister la citation Aneke");
  assert.ok(!/\(Aneke[^)]*\)\s*\[\d+\]/.test(introText), "le prompt ne doit plus contenir l'ancien format « (Auteur, Année) [n] »");
  console.log("✓ Le prompt de l'énoncé du problème reçoit bien le contexte de sources réelles, sans numérotation");

  fs.writeFileSync("/tmp/pipeline-test-output.docx", buffer);
  console.log("✓ Document .docx généré (/tmp/pipeline-test-output.docx), taille :", buffer.length, "octets");

  console.log("\nTous les tests d'intégration du pipeline sont passés.");
})().catch((err) => {
  console.error("✗ ÉCHEC:", err);
  process.exit(1);
});

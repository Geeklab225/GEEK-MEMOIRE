/**
 * MODULE DE RECHERCHE DOCUMENTAIRE RÉELLE
 * ========================================
 * Interroge de vraies bases bibliographiques publiques pour alimenter le
 * mémoire avec des sources réellement vérifiables (auteurs, année, revue,
 * DOI/PMID) — au lieu de laisser le modèle de langage inventer des
 * citations, ce qui est le principal risque d'intégrité académique de ce
 * type d'outil.
 *
 * Trois sources sont interrogées, toutes gratuites et sans clé API requise
 * pour un usage raisonnable :
 *   - PubMed / NCBI E-utilities   → littérature biomédicale et infirmière
 *   - CrossRef                     → métadonnées DOI toutes disciplines
 *   - OpenAlex                     → base ouverte, bon filet de secours
 *
 * ⚠️ IMPORTANT — testé partiellement seulement
 * L'environnement de développement utilisé pour construire cet agent a un
 * accès réseau sortant restreint (liste blanche de domaines, sans ces
 * APIs) : les appels ci-dessous n'ont donc PAS pu être exécutés en
 * conditions réelles pendant le développement. Ils sont écrits contre la
 * documentation officielle stable de chaque API, mais le TOUT PREMIER test
 * réel doit se faire une fois l'application déployée (ou lancée sur votre
 * propre machine avec un accès internet normal). Voir README.md.
 *
 * Ce que ce module NE couvre PAS encore, et qui nécessiterait une clé de
 * recherche web payante (Tavily, Bing Search API, SerpAPI, etc.) :
 *   - Recherche libre sur le site de l'OMS (who.int) — pas d'API publique
 *     de recherche ; nous exposons `WHO_FACT_SHEETS`, une petite liste
 *     organisée d'URLs de fiches OMS stables, à enrichir manuellement.
 *   - Mémoires et thèses en ligne (African Journals Online, DUMAS, etc.)
 *   - Littérature grise (rapports ministériels, PNTS-CI, etc.)
 */

const CONTACT_EMAIL = process.env.RESEARCH_CONTACT_EMAIL || "";
const NCBI_API_KEY = process.env.NCBI_API_KEY || "";

// Petite liste organisée de fiches d'information OMS stables et vérifiées,
// à enrichir manuellement au fil des thèmes traités. Clé = mot-clé simple,
// valeur = { title, url }. Ajoutez une entrée dès qu'un(e) étudiant(e)
// confirme la fiche OMS pertinente pour son thème.
// `year` est laissé à null tant que la date de dernière mise à jour de la
// fiche n'a pas été vérifiée manuellement (les fiches OMS sont révisées
// périodiquement, une date figée risquerait de devenir fausse silencieusement).
// Complétez-le vous-même après vérification sur who.int si vous voulez une
// année précise dans la référence Auteur-Année ; sinon l'agent écrit "s.d.".
const WHO_FACT_SHEETS = {
  "transfusion sanguine": {
    title: "Blood safety and availability",
    url: "https://www.who.int/news-room/fact-sheets/detail/blood-safety-and-availability",
    year: null,
  },
  "allaitement": {
    title: "Infant and young child feeding",
    url: "https://www.who.int/news-room/fact-sheets/detail/infant-and-young-child-feeding",
    year: null,
  },
  "vaccination": {
    title: "Immunization coverage",
    url: "https://www.who.int/news-room/fact-sheets/detail/immunization-coverage",
    year: null,
  },
  "cancer": {
    title: "Cancer",
    url: "https://www.who.int/news-room/fact-sheets/detail/cancer",
    year: null,
  },
  "soins palliatifs": {
    title: "Palliative care",
    url: "https://www.who.int/news-room/fact-sheets/detail/palliative-care",
    year: null,
  },
  "mortalité maternelle": {
    title: "Maternal mortality",
    url: "https://www.who.int/news-room/fact-sheets/detail/maternal-mortality",
    year: null,
  },
  "contraception": {
    title: "Family planning/contraception methods",
    url: "https://www.who.int/news-room/fact-sheets/detail/family-planning-contraception",
    year: null,
  },
};

function findWhoFactSheet(theme) {
  const lower = theme.toLowerCase();
  for (const [keyword, sheet] of Object.entries(WHO_FACT_SHEETS)) {
    if (lower.includes(keyword)) return sheet;
  }
  return null;
}

async function safeFetchJson(url, opts = {}) {
  const res = await fetch(url, { ...opts, headers: { accept: "application/json", ...(opts.headers || {}) } });
  if (!res.ok) throw new Error(`${url} → HTTP ${res.status}`);
  return res.json();
}

/**
 * PubMed via NCBI E-utilities : ESearch (liste de PMIDs) puis ESummary
 * (métadonnées). Documentation : https://www.ncbi.nlm.nih.gov/books/NBK25501/
 */
async function searchPubMed(query, { retmax = 8 } = {}) {
  const base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils";
  const common = `retmode=json${NCBI_API_KEY ? `&api_key=${NCBI_API_KEY}` : ""}${
    CONTACT_EMAIL ? `&email=${encodeURIComponent(CONTACT_EMAIL)}` : ""
  }`;

  const searchUrl = `${base}/esearch.fcgi?db=pubmed&term=${encodeURIComponent(query)}&retmax=${retmax}&${common}`;
  const searchData = await safeFetchJson(searchUrl);
  const ids = (searchData.esearchresult && searchData.esearchresult.idlist) || [];
  if (ids.length === 0) return [];

  const summaryUrl = `${base}/esummary.fcgi?db=pubmed&id=${ids.join(",")}&${common}`;
  const summaryData = await safeFetchJson(summaryUrl);
  const result = summaryData.result || {};

  return ids
    .map((id) => result[id])
    .filter(Boolean)
    .map((rec) => ({
      source: "pubmed",
      pmid: rec.uid,
      title: rec.title,
      authors: (rec.authors || []).map((a) => a.name),
      journal: rec.fulljournalname || rec.source,
      year: (rec.pubdate || "").match(/\d{4}/)?.[0] || null,
      doi: (rec.articleids || []).find((a) => a.idtype === "doi")?.value || null,
      url: `https://pubmed.ncbi.nlm.nih.gov/${rec.uid}/`,
    }));
}

/** CrossRef Works API : https://api.crossref.org/swagger-ui/index.html */
async function searchCrossRef(query, { rows = 8 } = {}) {
  const url = `https://api.crossref.org/works?query=${encodeURIComponent(query)}&rows=${rows}${
    CONTACT_EMAIL ? `&mailto=${encodeURIComponent(CONTACT_EMAIL)}` : ""
  }`;
  const data = await safeFetchJson(url);
  const items = (data.message && data.message.items) || [];

  return items.map((it) => ({
    source: "crossref",
    title: Array.isArray(it.title) ? it.title[0] : it.title,
    authors: (it.author || []).map((a) => [a.given, a.family].filter(Boolean).join(" ")),
    journal: Array.isArray(it["container-title"]) ? it["container-title"][0] : it["container-title"],
    year:
      it.published?.["date-parts"]?.[0]?.[0] ||
      it["published-print"]?.["date-parts"]?.[0]?.[0] ||
      it["published-online"]?.["date-parts"]?.[0]?.[0] ||
      null,
    doi: it.DOI || null,
    url: it.URL || (it.DOI ? `https://doi.org/${it.DOI}` : null),
  }));
}

/** OpenAlex Works API : https://docs.openalex.org/api-entities/works */
async function searchOpenAlex(query, { perPage = 8 } = {}) {
  const url = `https://api.openalex.org/works?search=${encodeURIComponent(query)}&per-page=${perPage}${
    CONTACT_EMAIL ? `&mailto=${encodeURIComponent(CONTACT_EMAIL)}` : ""
  }`;
  const data = await safeFetchJson(url);
  const items = data.results || [];

  return items.map((it) => ({
    source: "openalex",
    title: it.title || it.display_name,
    authors: (it.authorships || []).map((a) => a.author?.display_name).filter(Boolean),
    journal: it.primary_location?.source?.display_name || null,
    year: it.publication_year || null,
    doi: it.doi ? it.doi.replace("https://doi.org/", "") : null,
    url: it.doi || it.id,
  }));
}

function dedupeCitations(citations) {
  const seen = new Set();
  const out = [];
  for (const c of citations) {
    const key = (c.doi || c.pmid || c.title || "").toLowerCase().replace(/\s+/g, " ").trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(c);
  }
  return out;
}

/**
 * Interroge les trois sources en parallèle pour un thème donné, dédoublonne,
 * et retourne un pool de citations réelles utilisable pour (a) informer les
 * prompts IA des sections qui doivent citer des sources, et (b) construire
 * la bibliographie finale du document.
 *
 * Chaque appel réseau est isolé dans un try/catch : si une API est
 * indisponible ou en erreur (limite de débit, panne, etc.), la recherche
 * continue avec les autres sources plutôt que d'échouer entièrement.
 */
async function gatherSources(theme, { perSource = 6 } = {}) {
  const queries = [theme, `${theme} nurses knowledge attitude practice`, `${theme} Africa`];

  const results = await Promise.all(
    queries.flatMap((q) => [
      searchPubMed(q, { retmax: perSource }).catch((e) => {
        console.warn("[research] PubMed échec:", e.message);
        return [];
      }),
      searchCrossRef(q, { rows: perSource }).catch((e) => {
        console.warn("[research] CrossRef échec:", e.message);
        return [];
      }),
      searchOpenAlex(q, { perPage: perSource }).catch((e) => {
        console.warn("[research] OpenAlex échec:", e.message);
        return [];
      }),
    ])
  );

  const citations = dedupeCitations(results.flat()).filter((c) => c.title);
  const whoSheet = findWhoFactSheet(theme);

  return { citations, whoSheet };
}

/**
 * Extrait le nom de famille d'un auteur, en tenant compte du format qui
 * diffère selon la source :
 *  - PubMed (ESummary) donne "Nom Initiales", ex: "Aneke JC" → nom en 1er
 *  - CrossRef/OpenAlex donnent "Prénom Nom", ex: "R Yousef" → nom en dernier
 */
function extractSurname(fullName, source) {
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 1) return parts[0];
  return source === "pubmed" ? parts[0] : parts[parts.length - 1];
}

/**
 * Format court utilisé dans le corps du texte, selon la convention imposée
 * par l'INFAS : appel Auteur–Année, SANS numéro entre crochets (le guide
 * méthodologique officiel précise explicitement que le "système numérique
 * séquentiel" n'est PAS recommandé par l'école — voir slide 42 du support
 * fourni). Exemples : (Aneke, 2017) ; (Aneke et Okocha, 2017) ;
 * (Aneke et al., 2017) à partir de 3 auteurs.
 */
function inlineCitation(c) {
  const authors = c.authors || [];
  const year = c.year || "s.d.";
  if (authors.length === 0) return `(Auteur inconnu, ${year})`;

  const surname = (a) => extractSurname(a, c.source);
  if (authors.length === 1) return `(${surname(authors[0])}, ${year})`;
  if (authors.length === 2) return `(${surname(authors[0])} et ${surname(authors[1])}, ${year})`;
  return `(${surname(authors[0])} et al., ${year})`;
}

/**
 * Format long utilisé dans la bibliographie finale, alphabétique (méthode
 * "alpha-numérique" imposée par l'INFAS — voir slide 42-43) : nom de
 * famille, initiale(s) du prénom, année entre parenthèses, titre, source,
 * pages/lien. Les 6 premiers auteurs sont écrits en toutes lettres, comme
 * l'exige le guide (au-delà, "et al.").
 */
function referenceEntry(c) {
  const allAuthors = c.authors || [];
  const shown = allAuthors.slice(0, 6).map((a) => formatAuthorForBiblio(a, c.source));
  const authorsStr = shown.length ? shown.join(", ") + (allAuthors.length > 6 ? " et al." : "") : "[Auteur non identifié]";
  const link = c.doi ? `https://doi.org/${c.doi.replace(/^https?:\/\/doi\.org\//, "")}` : c.url || "";
  const title = String(c.title || "").trim().replace(/\.+$/, ""); // évite les doubles points finaux
  return `${authorsStr} (${c.year || "s.d."}). ${title}. ${c.journal ? c.journal + "." : "[revue non identifiée]."}${
    link ? ` Disponible sur : ${link}` : ""
  }`;
}

/** "Aneke JC" (pubmed) ou "R Yousef" (crossref/openalex) → "ANEKE J.C." style INFAS (Nom, Initiale(s) du prénom). */
function formatAuthorForBiblio(fullName, source) {
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].toUpperCase();
  if (source === "pubmed") {
    // "Aneke JC" → nom = "Aneke", initiales = "JC"
    const [surname, ...rest] = parts;
    const initials = rest.join("").split("").join(".") + ".";
    return `${surname.toUpperCase()} ${initials}`;
  }
  // "R Yousef" ou "Renata Yousef" → nom = dernier mot, initiale = 1ère lettre du reste
  const surname = parts[parts.length - 1];
  const initials = parts
    .slice(0, -1)
    .map((p) => p[0].toUpperCase() + ".")
    .join("");
  return `${surname.toUpperCase()} ${initials}`;
}

/**
 * Trie une liste de citations par ordre alphabétique du nom de famille du
 * premier auteur, conformément à la présentation "alpha-numérique" exigée
 * par l'INFAS pour la liste de références finale (le numéro qui précède
 * chaque entrée n'est qu'un repère de liste : il n'est jamais appelé dans
 * le texte, contrairement à un système [1][2][3]).
 */
function sortAlphabetically(citations) {
  return [...citations].sort((a, b) => {
    const surnameA = extractSurname((a.authors && a.authors[0]) || "zzz", a.source);
    const surnameB = extractSurname((b.authors && b.authors[0]) || "zzz", b.source);
    return surnameA.localeCompare(surnameB, "fr", { sensitivity: "base" });
  });
}

module.exports = {
  searchPubMed,
  searchCrossRef,
  searchOpenAlex,
  gatherSources,
  findWhoFactSheet,
  inlineCitation,
  referenceEntry,
  sortAlphabetically,
  extractSurname,
  WHO_FACT_SHEETS,
};

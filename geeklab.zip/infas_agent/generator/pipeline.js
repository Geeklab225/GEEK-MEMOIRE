const { buildDefaultStructure } = require("./structure");
const { generateSection, hasApiKey } = require("./llm");
const research = require("./research");
const docxBuilder = require("./docxBuilder");

/**
 * Construit le bloc de contexte injecté dans les prompts des sections qui
 * doivent citer des sources réelles, et la bibliographie finale.
 *
 * Conforme aux règles officielles INFAS (support méthodologique fourni,
 * slides 42-46) :
 *  - appel dans le texte : AUTEUR-ANNÉE, jamais de numéro entre crochets
 *    ("système numérique séquentiel (non recommandé / INFAS)") ;
 *  - liste de références : "ALPHA-NUMÉRIQUE", c'est-à-dire triée par ordre
 *    alphabétique du nom du premier auteur (les numéros de la liste ne sont
 *    que des repères de position, jamais appelés dans le texte).
 *
 * La fiche OMS, quand elle existe, est traitée comme une source parmi les
 * autres et prend sa place alphabétique sous "Organisation mondiale de la
 * santé" plutôt que d'être toujours placée en tête.
 */
function buildSourcesContext({ citations, whoSheet }) {
  const items = citations.map((c) => ({
    key: research.extractSurname((c.authors && c.authors[0]) || "zzz", c.source),
    inline: research.inlineCitation(c),
    full: research.referenceEntry(c),
  }));

  if (whoSheet) {
    const year = whoSheet.year || "s.d.";
    items.push({
      key: "Organisation mondiale de la santé",
      inline: `(OMS, ${year})`,
      full: `Organisation Mondiale de la Santé (OMS) (${year}). ${whoSheet.title}. Disponible sur : ${whoSheet.url}`,
    });
  }

  items.sort((a, b) => a.key.localeCompare(b.key, "fr", { sensitivity: "base" }));

  if (items.length === 0) {
    return {
      block:
        "Aucune source vérifiée n'a pu être récupérée automatiquement pour ce thème (recherche documentaire " +
        "indisponible ou infructueuse). N'invente AUCUNE statistique, citation ou nom d'auteur : utilise des " +
        "espaces réservés [DONNÉE À VÉRIFIER] à la place.",
      referenceList: [],
    };
  }

  const block =
    "Voici des sources réelles vérifiées, trouvées automatiquement (PubMed / CrossRef / OpenAlex" +
    (whoSheet ? " / OMS" : "") +
    "). Cite-les dans le texte au format Auteur-Année indiqué entre parenthèses (ex. " +
    items[0].inline +
    "), SANS numéro entre crochets : l'INFAS ne recommande PAS le système numérique séquentiel. " +
    "N'invente aucune autre source, statistique ou nom d'auteur. Si tu as besoin d'un point que ces sources ne " +
    "couvrent pas, écris [DONNÉE À VÉRIFIER] plutôt que d'inventer :\n\n" +
    items.map((it) => `- ${it.inline} → ${it.full}`).join("\n");

  return { block, referenceList: items.map((it) => it.full) };
}

/**
 * Génère le contenu de chaque section du mémoire, puis assemble le .docx.
 * Retourne { content, buffer } — `content` est sauvegardé en base
 * (content_json) pour permettre une régénération ou une édition ultérieure
 * sans repayer chaque appel IA.
 */
async function generateMemoire(meta) {
  const structure = buildDefaultStructure(meta);
  const content = {};

  // --- Recherche documentaire réelle, une seule fois pour tout le mémoire ---
  let sources = { citations: [], whoSheet: null };
  try {
    sources = await research.gatherSources(meta.theme);
  } catch (err) {
    console.warn("[pipeline] Recherche documentaire indisponible :", err.message);
  }
  const { block: sourcesBlock, referenceList } = buildSourcesContext(sources);

  for (const section of structure) {
    // Sections purement structurelles : rien à générer par l'IA.
    if (["titlepage", "toc", "partieDivider", "dedicaces", "placeholderList"].includes(section.kind)) continue;
    // Sections "regroupement" (ex: "2-1 MATÉRIEL ET MÉTHODES") : juste un
    // titre, le contenu se trouve dans leurs sous-sections (2-1-1, 2-1-2…).
    if (section.headerOnly) continue;

    if (section.isBibliography) {
      // Bibliographie construite directement à partir des sources réellement
      // trouvées (pas de génération par le modèle de langage) — c'est le
      // point le plus sensible sur le plan de l'intégrité académique.
      content[section.id] = referenceList;
      continue;
    }

    const promptWithSources = section.needsCitations ? `${sourcesBlock}\n\n${section.prompt}` : section.prompt;

    if (section.kind === "definitions") {
      const raw = await generateSection(promptWithSources, meta);
      // Attendu : lignes "Terme : définition". On tente un parsing simple ;
      // en cas d'échec (placeholder sans clé API par ex.), on stocke le texte brut.
      const lines = raw.split(/\n+/).map((l) => l.trim()).filter(Boolean);
      const parsed = lines
        .map((l) => {
          const m = l.match(/^\*?\*?([^:]{2,60}?)\*?\*?\s*:\s*(.+)$/);
          return m ? { term: m[1].trim(), text: m[2].trim() } : null;
        })
        .filter(Boolean);
      content[section.id] = parsed.length ? parsed : raw;
      continue;
    }

    if (section.subsections) {
      const subResult = {};
      for (const sub of section.subsections) {
        subResult[sub] = await generateSection(`${promptWithSources}\n\nRédige uniquement la sous-partie « ${sub} ».`, meta);
      }
      content[section.id] = subResult;
      continue;
    }

    content[section.id] = await generateSection(promptWithSources, meta);
  }

  const buffer = await docxBuilder.build(
    {
      theme: meta.theme,
      studentNames: meta.studentNames,
      directorName: meta.directorName,
      coDirectorName: meta.coDirectorName,
      presidentJury: meta.presidentJury,
      assesseur1: meta.assesseur1,
      assesseur2: meta.assesseur2,
      academicYear: meta.academicYear,
      antenne: meta.antenne,
      ville: meta.ville,
      antenneCode: meta.antenneCode,
      filiere: meta.filiere,
      filiereCode: meta.filiereCode,
      niveau: meta.niveau,
      numeroOrdre: meta.numeroOrdre,
      soutenanceYear: meta.soutenanceYear,
      soutenanceDate: meta.soutenanceDate,
      pays: meta.pays,
      institution: "INFAS",
    },
    structure,
    content
  );

  return { content, buffer, usedLLM: hasApiKey, sourcesFound: sources.citations.length, whoSheetFound: Boolean(sources.whoSheet) };
}

module.exports = { generateMemoire };

/**
 * Test manuel (sans framework) du parsing de research.js, avec des réponses
 * JSON imitant fidèlement le format documenté de chaque API (PubMed
 * ESearch/ESummary, CrossRef Works, OpenAlex Works). Nécessaire car le
 * réseau sortant de cet environnement de développement ne permet pas
 * d'appeler les vraies APIs (voir avertissement en tête de research.js).
 *
 * Couvre aussi le format de citation imposé par l'INFAS (support
 * méthodologique officiel, slide 42) : appel dans le texte AUTEUR-ANNÉE
 * sans numéro entre crochets, et liste de références "alpha-numérique"
 * (triée alphabétiquement, 6 premiers auteurs écrits en toutes lettres).
 *
 * Lancer avec : node generator/research.test.js
 */

const assert = require("assert");

// --- Mock fetch avant de charger le module testé ---
const FIXTURES = {
  // esearch.fcgi
  "esearch.fcgi": {
    esearchresult: { idlist: ["12345678"] },
  },
  // esummary.fcgi
  "esummary.fcgi": {
    result: {
      uids: ["12345678"],
      "12345678": {
        uid: "12345678",
        title: "Knowledge, attitude and practice of nurses regarding blood transfusion safety.",
        authors: [{ name: "Aneke JC" }, { name: "Okocha CE" }],
        fulljournalname: "Journal of Blood Transfusion",
        pubdate: "2017 Jun",
        articleids: [{ idtype: "doi", value: "10.4103/ejh.ejh_25_17" }],
      },
    },
  },
  // api.crossref.org/works
  "api.crossref.org": {
    message: {
      items: [
        {
          title: ["Nurses' knowledge and practice of blood transfusion safety"],
          author: [{ given: "R", family: "Yousef" }],
          "container-title": ["Egyptian Journal of Health Care"],
          published: { "date-parts": [[2024]] },
          DOI: "10.21608/ejhc.2024.380209",
          URL: "https://doi.org/10.21608/ejhc.2024.380209",
        },
      ],
    },
  },
  // api.openalex.org/works
  "api.openalex.org": {
    results: [
      {
        title: "Blood transfusion knowledge and practice among nurses in Turkey",
        authorships: [{ author: { display_name: "A Akyol" } }],
        primary_location: { source: { display_name: "Asian Journal of Transfusion Science" } },
        publication_year: 2023,
        doi: "https://doi.org/10.4103/0973-6247.375888",
        id: "https://openalex.org/W123",
      },
    ],
  },
};

global.fetch = async (url) => {
  const match = Object.keys(FIXTURES).find((key) => url.includes(key));
  if (!match) throw new Error(`Aucune fixture pour l'URL : ${url}`);
  return {
    ok: true,
    status: 200,
    json: async () => FIXTURES[match],
  };
};

const research = require("./research");

(async () => {
  // --- searchPubMed ---
  const pubmed = await research.searchPubMed("blood transfusion nurses knowledge");
  assert.strictEqual(pubmed.length, 1);
  assert.strictEqual(pubmed[0].pmid, "12345678");
  assert.strictEqual(pubmed[0].doi, "10.4103/ejh.ejh_25_17");
  assert.strictEqual(pubmed[0].year, "2017");
  assert.deepStrictEqual(pubmed[0].authors, ["Aneke JC", "Okocha CE"]);
  console.log("✓ searchPubMed parse correctement ESearch + ESummary");

  // --- searchCrossRef ---
  const crossref = await research.searchCrossRef("blood transfusion nurses knowledge");
  assert.strictEqual(crossref.length, 1);
  assert.strictEqual(crossref[0].doi, "10.21608/ejhc.2024.380209");
  assert.strictEqual(crossref[0].year, 2024);
  assert.strictEqual(crossref[0].authors[0], "R Yousef");
  console.log("✓ searchCrossRef parse correctement la réponse Works");

  // --- searchOpenAlex ---
  const openalex = await research.searchOpenAlex("blood transfusion nurses knowledge");
  assert.strictEqual(openalex.length, 1);
  assert.strictEqual(openalex[0].year, 2023);
  assert.strictEqual(openalex[0].journal, "Asian Journal of Transfusion Science");
  console.log("✓ searchOpenAlex parse correctement la réponse Works");

  // --- dedupe + gatherSources (avec les 3 mocks combinés) ---
  const { citations, whoSheet } = await research.gatherSources("transfusion sanguine infirmiers", { perSource: 3 });
  assert.ok(citations.length >= 3, "devrait combiner les 3 sources après dédoublonnage");
  assert.ok(whoSheet && whoSheet.url.includes("blood-safety"), "devrait retrouver la fiche OMS transfusion");
  console.log("✓ gatherSources combine les sources, dédoublonne, et retrouve la fiche OMS pertinente");

  // --- formatage des citations (Auteur-Année, SANS numéro entre crochets) ---
  const inline2 = research.inlineCitation(pubmed[0]); // 2 auteurs → "et"
  assert.strictEqual(inline2, "(Aneke et Okocha, 2017)");
  console.log("✓ inlineCitation (2 auteurs) formate correctement :", inline2);

  const inline1 = research.inlineCitation(crossref[0]); // 1 auteur
  assert.strictEqual(inline1, "(Yousef, 2024)");
  console.log("✓ inlineCitation (1 auteur) formate correctement :", inline1);

  const manyAuthors = { ...pubmed[0], authors: ["Aneke JC", "Okocha CE", "Diallo M"] };
  assert.strictEqual(research.inlineCitation(manyAuthors), "(Aneke et al., 2017)");
  console.log("✓ inlineCitation (3+ auteurs) utilise « et al. »");

  const entry = research.referenceEntry(crossref[0]);
  assert.ok(entry.startsWith("YOUSEF R. (2024)."), "l'entrée doit commencer par NOM Initiale (Année) — convention INFAS");
  assert.ok(entry.includes("doi.org/10.21608/ejhc.2024.380209"), "l'entrée doit inclure le lien DOI");
  console.log("✓ referenceEntry formate correctement :", entry);

  const entryPubmed = research.referenceEntry(pubmed[0]);
  assert.ok(entryPubmed.startsWith("ANEKE J.C., OKOCHA C.E. (2017)."), "format PubMed « Surname Initiales » doit devenir NOM I.I.");
  console.log("✓ referenceEntry (source PubMed) formate correctement :", entryPubmed);

  // --- tri alphabétique "alpha-numérique" exigé par l'INFAS ---
  const sorted = research.sortAlphabetically([crossref[0], pubmed[0], openalex[0]]);
  const surnames = sorted.map((c) => research.extractSurname(c.authors[0], c.source));
  assert.deepStrictEqual(surnames, ["Akyol", "Aneke", "Yousef"], "tri alphabétique attendu : Akyol, Aneke, Yousef");
  console.log("✓ sortAlphabetically trie correctement par nom de famille du premier auteur :", surnames.join(", "));

  console.log("\nTous les tests de research.js sont passés (avec des réponses API simulées).");
})().catch((err) => {
  console.error("✗ ÉCHEC:", err);
  process.exit(1);
});

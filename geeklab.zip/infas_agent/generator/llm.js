/**
 * Wrapper autour du modèle d'IA utilisé pour rédiger chaque section du
 * mémoire. Tant qu'aucune clé API n'est configurée (ANTHROPIC_API_KEY dans
 * .env), on retourne un texte-espace-réservé clairement identifiable : le
 * document généré reste entièrement structuré et mis en forme, seul le
 * contenu rédactionnel manque.
 *
 * Une fois la clé ajoutée, `generateSection` appelle l'API Messages
 * d'Anthropic (voir docs.claude.com) avec le modèle défini dans .env
 * (CLAUDE_MODEL, ex: "claude-sonnet-4-5-20250929").
 */

require("dotenv").config();

const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-4-5-20250929";
const API_URL = "https://api.anthropic.com/v1/messages";

const SYSTEM_PROMPT = `Tu es un assistant de rédaction académique spécialisé dans les mémoires de fin de
cycle des instituts de formation en sciences infirmières et sages-femmes en Côte d'Ivoire (INFAS).
Règles strictes :
- Rédige exclusivement en français, dans un style académique clair et fluide.
- N'invente JAMAIS de statistique, de nom d'auteur, de citation ou de référence bibliographique.
  Si une donnée réelle n'est pas fournie dans le contexte, insère un espace réservé explicite du
  type [DONNÉE À VÉRIFIER — sujet] plutôt que de fabriquer un chiffre ou une source.
- Respecte scrupuleusement la structure et les consignes de la section demandée.
- Ne répète pas le titre de la section dans ta réponse : ne rédige que le contenu (paragraphes).`;

async function generateSection(prompt, { theme } = {}) {
  if (!API_KEY) {
    return (
      `[CONTENU À GÉNÉRER PAR L'IA]\n` +
      `Cette section sera rédigée automatiquement une fois une clé ANTHROPIC_API_KEY configurée ` +
      `dans le fichier .env (voir README.md). Instruction prévue pour cette section :\n« ${prompt} »`
    );
  }

  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1400,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: prompt }],
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Appel API Claude échoué (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const textBlock = (data.content || []).find((b) => b.type === "text");
  return textBlock ? textBlock.text.trim() : "[Réponse vide de l'API]";
}

module.exports = { generateSection, hasApiKey: Boolean(API_KEY) };

/**
 * Moteur de mise en page Word (.docx) pour les mémoires INFAS — conforme au
 * support méthodologique officiel fourni par l'école (slides 11-16, 47-49) :
 *
 *  - Police Times New Roman 14, interligne 1,5, texte justifié
 *  - Marges : haut/bas 2,5 cm, gauche 3 cm, droite 2 cm
 *  - A4 recto uniquement, fond blanc, encadré orange sur chaque page
 *  - En-tête = sujet du mémoire ; pied de page = Nom et Prénoms, niveau,
 *    année académique
 *  - Pagination : la page de garde n'est pas numérotée ; le sommaire, les
 *    dédicaces, remerciements et listes sont numérotés en chiffres romains ;
 *    l'introduction jusqu'aux références en chiffres arabes ; les annexes
 *    et le résumé reprennent une numérotation en chiffres romains (slide 16)
 *  - Page de garde : pays, ministère, institut, type de rapport, objet,
 *    titre, présentateur(s), date/lieu de soutenance, composition du jury,
 *    numéro de mémoire, année de soutenance, numéro d'ordre (slides 11-14)
 *  - Dédicaces : une page par impétrant, sans laïus (slide 15, 17, 49)
 */

const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Header, Footer, PageNumber, BorderStyle, LevelFormat,
  TableOfContents, NumberFormat,
} = require("docx");

const { buildNumeroMemoire } = require("./antennes");

const ORANGE = "C1440E";
const FONT = "Times New Roman";
const BODY_SIZE = 28; // 14pt (docx sizes are in half-points)

// cm → twips (1 cm = 566.929 twips)
const cm = (n) => Math.round(n * 566.929);

const PAGE_MARGIN = { top: cm(2.5), bottom: cm(2.5), left: cm(3), right: cm(2), header: cm(1.0), footer: cm(1.0) };
const PAGE_BORDER = {
  pageBorderTop: { style: BorderStyle.SINGLE, size: 12, color: ORANGE, space: 18 },
  pageBorderBottom: { style: BorderStyle.SINGLE, size: 12, color: ORANGE, space: 18 },
  pageBorderLeft: { style: BorderStyle.SINGLE, size: 12, color: ORANGE, space: 18 },
  pageBorderRight: { style: BorderStyle.SINGLE, size: 12, color: ORANGE, space: 18 },
};

function titleRun(text, opts = {}) {
  return new TextRun({ text, bold: true, size: opts.size || 32, font: FONT, ...opts });
}

// Word applique une couleur de thème (bleu) aux styles Heading1-4 intégrés
// par défaut ; l'INFAS n'exige nulle part un texte en couleur pour les
// titres de section (seul l'encadré de page doit être orange), donc on
// force explicitement le noir sur chaque TextRun de titre.
const HEADING_COLOR = "000000";

function h1(text, opts = {}) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    pageBreakBefore: !!opts.pageBreak,
    alignment: AlignmentType.CENTER,
    spacing: { before: 300, after: 240 },
    children: [new TextRun({ text: String(text).toUpperCase(), bold: true, size: 32, font: FONT, color: HEADING_COLOR })],
  });
}

function h2(text, opts = {}) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    pageBreakBefore: !!opts.pageBreak,
    alignment: AlignmentType.LEFT,
    spacing: { before: 260, after: 140 },
    children: [new TextRun({ text, bold: true, size: 30, font: FONT, color: HEADING_COLOR })],
  });
}

function h3(text, opts = {}) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    pageBreakBefore: !!opts.pageBreak,
    alignment: AlignmentType.LEFT,
    spacing: { before: 220, after: 120 },
    children: [new TextRun({ text, bold: true, size: 28, font: FONT, color: HEADING_COLOR })],
  });
}

function h4(text, opts = {}) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_4,
    pageBreakBefore: !!opts.pageBreak,
    alignment: AlignmentType.LEFT,
    spacing: { before: 200, after: 100 },
    children: [new TextRun({ text, bold: true, italics: true, size: 28, font: FONT, color: HEADING_COLOR })],
  });
}

const HEADING_FN = { h1, h2, h3, h4 };

// Sous-titre "run-in" utilisé pour les subsections déclarées dans
// generator/structure.js (ex: "Milieu de l'étude", "Critères d'inclusion").
// Volontairement PAS un style Heading Word, pour ne pas polluer le sommaire
// automatique au-delà du niveau imposé par l'INFAS.
function subheading(text) {
  return new Paragraph({
    alignment: AlignmentType.LEFT,
    spacing: { before: 160, after: 80 },
    children: [new TextRun({ text, bold: true, italics: true, size: BODY_SIZE, font: FONT, color: HEADING_COLOR })],
  });
}

function p(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: 160, line: 360 },
    children: [new TextRun({ text, size: BODY_SIZE, font: FONT })],
  });
}

function numbered(text, ref) {
  return new Paragraph({
    numbering: { reference: ref, level: 0 },
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: 100, line: 360 },
    children: [new TextRun({ text, size: BODY_SIZE, font: FONT })],
  });
}

function definition(term, text) {
  return new Paragraph({
    spacing: { after: 140, line: 360 },
    alignment: AlignmentType.JUSTIFIED,
    children: [
      new TextRun({ text: `${term} : `, bold: true, size: BODY_SIZE, font: FONT }),
      new TextRun({ text, size: BODY_SIZE, font: FONT }),
    ],
  });
}

function partieDivider(label, title) {
  return [
    new Paragraph({ pageBreakBefore: true, spacing: { before: 2600 }, children: [] }),
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      alignment: AlignmentType.CENTER,
      border: {
        top: { style: BorderStyle.DOUBLE, size: 12, color: ORANGE, space: 20 },
        bottom: { style: BorderStyle.DOUBLE, size: 12, color: ORANGE, space: 20 },
      },
      spacing: { before: 400, after: 200 },
      children: [new TextRun({ text: label, bold: true, size: 32, color: ORANGE, font: FONT })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 200 },
      children: [new TextRun({ text: String(title).toUpperCase(), bold: true, size: 40, font: FONT })],
    }),
  ];
}

// Détecte le texte-espace-réservé produit par generator/llm.js quand aucune
// clé API n'est configurée, pour éviter de le découper en fausse liste
// numérotée ligne par ligne.
function isPlaceholder(val) {
  return typeof val === "string" && val.trimStart().startsWith("[CONTENU À GÉNÉRER");
}

function textToParagraphs(text) {
  return String(text)
    .split(/\n{2,}/)
    .map((chunk) => chunk.trim())
    .filter(Boolean)
    .map((chunk) => p(chunk));
}

/**
 * "NOM Prénom" → "NOM" en gras petites majuscules puis "Prénom" — on affiche
 * simplement le nom tel que saisi par l'étudiant(e) : l'INFAS demande le nom
 * en MAJUSCULES et les prénoms avec initiale majuscule (slide 14), c'est à
 * l'étudiant(e) de le saisir ainsi ; l'agent ne réécrit pas un nom propre
 * qu'il ne connaît pas avec certitude.
 */
function buildTitlePage(meta) {
  const impetrants = String(meta.studentNames || "")
    .split(/[,;\n]+/)
    .map((s) => s.trim())
    .filter(Boolean);
  const presentateurs = impetrants.length ? impetrants.join(" et ") : "[Nom(s) et Prénoms de l'étudiant(e)]";
  const numeroMemoire = buildNumeroMemoire(meta);

  const juryLine = (role, name) =>
    new Paragraph({
      alignment: AlignmentType.LEFT,
      spacing: { after: 60 },
      children: [
        new TextRun({ text: `${role} : `, bold: true, size: BODY_SIZE, font: FONT }),
        new TextRun({ text: name || "[À COMPLÉTER]", size: BODY_SIZE, font: FONT }),
      ],
    });

  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 }, children: [new TextRun({ text: (meta.pays || "RÉPUBLIQUE DE CÔTE D'IVOIRE").toUpperCase(), bold: true, size: BODY_SIZE, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "MINISTÈRE DE LA SANTÉ, DE L'HYGIÈNE PUBLIQUE ET DE LA COUVERTURE MALADIE UNIVERSELLE", bold: true, size: 24, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 }, children: [new TextRun({ text: "[LOGO INFAS]", italics: true, size: 20, color: "888888", font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: `INSTITUT NATIONAL DE FORMATION DES AGENTS DE SANTÉ (INFAS)`, bold: true, size: 26, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 500 }, children: [new TextRun({ text: `ANTENNE ${(meta.antenne || meta.ville || "[VILLE]").toUpperCase()}`, bold: true, size: 24, font: FONT })] }),

    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "MÉMOIRE DE FIN DE CYCLE", bold: true, size: 26, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 400 }, children: [new TextRun({ text: `En vue de l'obtention du Diplôme d'État de ${meta.filiere || "[Filière]"}`, italics: true, size: 24, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 500 }, children: [titleRun(meta.theme, { size: 32, color: ORANGE })] }),

    new Paragraph({ alignment: AlignmentType.LEFT, spacing: { before: 200, after: 80 }, children: [new TextRun({ text: `Présenté par : ${presentateurs}`, bold: true, size: BODY_SIZE, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 300 }, children: [new TextRun({ text: `Niveau : ${meta.niveau || "[IDE3 / SFM3]"}`, size: BODY_SIZE, font: FONT })] }),

    new Paragraph({ alignment: AlignmentType.LEFT, spacing: { before: 200, after: 100 }, children: [new TextRun({ text: "COMPOSITION DU JURY", bold: true, underline: {}, size: BODY_SIZE, font: FONT })] }),
    juryLine("Président du jury", meta.presidentJury),
    juryLine("Directeur de mémoire", meta.directorName),
    juryLine("Co-Directeur de mémoire", meta.coDirectorName),
    juryLine("Assesseur 1", meta.assesseur1),
    juryLine("Assesseur 2", meta.assesseur2),

    new Paragraph({ alignment: AlignmentType.LEFT, spacing: { before: 400, after: 60 }, children: [new TextRun({ text: `Numéro de mémoire : ${numeroMemoire}`, bold: true, size: BODY_SIZE, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 60 }, children: [new TextRun({ text: `Numéro d'ordre : ${meta.numeroOrdre || "[À COMPLÉTER]"}`, size: BODY_SIZE, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 60 }, children: [new TextRun({ text: `Année de soutenance : ${meta.soutenanceYear || meta.academicYear || "[À COMPLÉTER]"}`, size: BODY_SIZE, font: FONT })] }),
    new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 300 }, children: [new TextRun({ text: `Date et lieu de soutenance : ${meta.soutenanceDate || "[À COMPLÉTER]"} — ${meta.ville || meta.antenne || "[Ville]"}`, size: BODY_SIZE, font: FONT })] }),

    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 300 }, children: [new TextRun({ text: `Année académique ${meta.academicYear || "[À COMPLÉTER]"}`, bold: true, size: BODY_SIZE, font: FONT })] }),
  ];
}

/**
 * Slides 15, 17, 49 : pas de laïus, une page PAR impétrant, simple
 * énumération des personnes à qui le travail est dédié.
 */
function buildDedicacesPages(section) {
  const impetrants = section.impetrants && section.impetrants.length ? section.impetrants : ["[Étudiant(e)]"];
  const out = [h1(section.title, { pageBreak: true })];
  impetrants.forEach((name, i) => {
    out.push(
      new Paragraph({
        pageBreakBefore: i > 0,
        alignment: AlignmentType.CENTER,
        spacing: { before: 200, after: 300 },
        children: [new TextRun({ text: `Dédicace de ${name}`, italics: true, size: 26, font: FONT })],
      })
    );
    for (let j = 1; j <= 3; j++) {
      out.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 160 },
          children: [new TextRun({ text: `[NOM DE LA PERSONNE ${j} À QUI CE TRAVAIL EST DÉDIÉ — à compléter par ${name}]`, size: BODY_SIZE, font: FONT })],
        })
      );
    }
  });
  return out;
}

function buildPlaceholderList(section) {
  return [
    h1(section.title, { pageBreak: true }),
    new Paragraph({
      alignment: AlignmentType.JUSTIFIED,
      spacing: { after: 160, line: 360 },
      children: [new TextRun({ text: section.note || "", italics: true, size: BODY_SIZE, color: "555555", font: FONT })],
    }),
  ];
}

// --- Mise en page de section Word (pays commun à front/body/back) ---
function sectionPage(formatType, start) {
  return {
    size: { width: 11906, height: 16838 }, // A4
    margin: PAGE_MARGIN,
    borders: PAGE_BORDER,
    pageNumbers: formatType ? { start, formatType } : undefined,
  };
}

function buildHeader(meta) {
  return new Header({
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: ORANGE, space: 4 } },
        children: [new TextRun({ text: meta.theme, size: 18, color: "555555", font: FONT })],
      }),
    ],
  });
}

function buildFooter(meta) {
  const line = `${meta.studentNames || "[Nom(s) et Prénoms]"} ; ${meta.niveau || "[Niveau]"} ; ${meta.academicYear || "[Année académique]"}`;
  return new Footer({
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        border: { top: { style: BorderStyle.SINGLE, size: 4, color: ORANGE, space: 4 } },
        children: [
          new TextRun({ text: `${line} — Page `, size: 16, color: "555555", font: FONT }),
          new TextRun({ children: [PageNumber.CURRENT], size: 16, color: "555555", font: FONT }),
        ],
      }),
    ],
  });
}

/**
 * @param {object} meta - métadonnées du mémoire (thème, étudiant(e)s, jury,
 *   antenne, filière, niveau, numéro de mémoire, etc. — voir routes/memoires.js)
 * @param {Array}  structure - sortie de generator/structure.js
 * @param {Object} content - map { sectionId: string | { [sub]: string } | string[] }
 */
function build(meta, structure, content) {
  const numberingRefs = structure
    .filter((s) => s.numbered)
    .map((s) => ({
      reference: `num-${s.id}`,
      levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START }],
    }));
  numberingRefs.push({
    reference: "num-references",
    levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START }],
  });

  const titleBody = [];
  const frontBody = [];
  const mainBody = [];
  const backBody = [];

  const zoneTarget = (zone) => (zone === "front" ? frontBody : zone === "back" ? backBody : mainBody);

  for (const section of structure) {
    if (section.kind === "titlepage") {
      titleBody.push(...buildTitlePage(meta));
      continue;
    }

    const target = zoneTarget(section.zone);

    switch (section.kind) {
      case "toc":
        target.push(h1(section.title || "SOMMAIRE"));
        target.push(new TableOfContents("Sommaire", { hyperlink: true, headingStyleRange: "1-3" }));
        break;

      case "dedicaces":
        target.push(...buildDedicacesPages(section));
        break;

      case "remerciements":
        target.push(h1(section.title, { pageBreak: true }));
        target.push(...textToParagraphs(content[section.id] || ""));
        break;

      case "placeholderList":
        target.push(...buildPlaceholderList(section));
        break;

      case "definitions": {
        target.push(h1(section.title, { pageBreak: section.zone === "front" }));
        const entries = content[section.id];
        if (Array.isArray(entries)) {
          entries.forEach(({ term, text }) => target.push(definition(term, text)));
        } else {
          target.push(...textToParagraphs(entries || ""));
        }
        break;
      }

      case "partieDivider":
        // La page "Partie" est une page à part entière : le premier chapitre
        // qui suit démarre sur une nouvelle page.
        target.push(...partieDivider(section.label, section.title));
        target.push(new Paragraph({ children: [], pageBreakBefore: true }));
        break;

      case "h1":
      case "h2":
      case "h3":
      case "h4": {
        const headingFn = HEADING_FN[section.kind];
        const label = section.numberPrefix ? `${section.numberPrefix}  ${section.title}` : section.title;
        target.push(headingFn(label, { pageBreak: section.pageBreak }));

        if (section.headerOnly) break;

        const val = content[section.id];
        if (section.subsections && val && typeof val === "object" && !Array.isArray(val)) {
          for (const sub of section.subsections) {
            target.push(subheading(sub));
            target.push(...textToParagraphs(val[sub] || ""));
          }
        } else if (section.isBibliography) {
          const refs = Array.isArray(val) ? val : [];
          if (refs.length === 0) {
            target.push(
              p(
                "[Bibliographie à générer — voir la note méthodologique. Chaque source réellement vérifiée trouvée " +
                  "automatiquement (PubMed / CrossRef / OpenAlex / OMS) sera listée ici par ordre alphabétique du nom " +
                  "du premier auteur, conformément à la présentation « alpha-numérique » exigée par l'INFAS.]"
              )
            );
          } else {
            refs.forEach((ref) => target.push(numbered(ref, "num-references")));
          }
        } else if (section.numbered && !isPlaceholder(val)) {
          const lines = Array.isArray(val)
            ? val
            : String(val || "").split(/\n+/).map((l) => l.replace(/^\s*\d+[.)]\s*/, "").trim()).filter(Boolean);
          lines.forEach((line) => target.push(numbered(line, `num-${section.id}`)));
        } else {
          target.push(...textToParagraphs(val || ""));
        }
        break;
      }

      default:
        break;
    }
  }

  const doc = new Document({
    features: { updateFields: true },
    numbering: { config: numberingRefs },
    styles: { default: { document: { run: { font: FONT, size: BODY_SIZE } } } },
    sections: [
      {
        // Page de garde : pas d'en-tête/pied de page, pas de numéro visible.
        properties: { page: sectionPage(null) },
        children: titleBody,
      },
      {
        // Avant-propos : sommaire, dédicaces, remerciements, listes — chiffres romains (slide 10, 16)
        properties: { page: sectionPage(NumberFormat.LOWER_ROMAN, 1) },
        headers: { default: buildHeader(meta) },
        footers: { default: buildFooter(meta) },
        children: frontBody,
      },
      {
        // Corps du mémoire : introduction → références — chiffres arabes (slide 16)
        properties: { page: sectionPage(NumberFormat.DECIMAL, 1) },
        headers: { default: buildHeader(meta) },
        footers: { default: buildFooter(meta) },
        children: mainBody,
      },
      {
        // Annexes / résumé : reprise des chiffres romains, à la suite de la
        // pagination arabe (l'INFAS précise que l'arabe "prend fin aux
        // références" — hypothèse retenue : la numérotation continue mais
        // change de format d'affichage ; voir README, "Hypothèses retenues").
        properties: { page: sectionPage(NumberFormat.LOWER_ROMAN) },
        headers: { default: buildHeader(meta) },
        footers: { default: buildFooter(meta) },
        children: backBody,
      },
    ],
  });

  return Packer.toBuffer(doc);
}

module.exports = { build };

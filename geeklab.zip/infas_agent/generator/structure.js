/**
 * STRUCTURE OFFICIELLE DU MÉMOIRE INFAS
 * ======================================
 * Reconstruite directement à partir du support méthodologique officiel
 * fourni par l'INFAS (« Rédaction Mémo 2024 IDE3 SFM3 ABG », 54 diapositives,
 * antenne d'Abengourou), extrait intégral dans
 * /home/claude/work/infas_methodology/methodologie.md. Toutes les sections,
 * l'ordre, la numérotation manuelle (2-1, 2-1-1, 2-1-1-1…) et les règles de
 * présentation ci-dessous reprennent fidèlement ce document (slides 10, 13,
 * 15-27, 33-49).
 *
 * Chaque section décrit :
 *  - id: identifiant stable utilisé dans content_json
 *  - kind: "titlepage" | "toc" | "dedicaces" | "remerciements" |
 *          "definitions" | "placeholderList" | "h1" | "h2" | "h3" | "h4" |
 *          "partieDivider"
 *  - zone: "front" (pagination chiffres romains, avant l'introduction) |
 *          "body" (pagination chiffres arabes, de l'introduction aux
 *          références) | "back" (chiffres romains, après les références) —
 *          voir slide 16. Par défaut : "body".
 *  - numberPrefix: numérotation manuelle façon INFAS ("2-1-1-1"), à
 *    intégrer directement dans le texte du titre plutôt que de laisser
 *    Word numéroter automatiquement (l'école utilise une numérotation à
 *    tirets, pas la numérotation multiniveau standard de Word).
 *  - title: titre affiché (pour h1/h2/h3/h4/partieDivider)
 *  - prompt: instruction donnée au modèle IA pour rédiger cette section
 *  - headerOnly: true si la section n'est qu'un titre de regroupement sans
 *    contenu propre (ex: "2-1 MATÉRIEL ET MÉTHODES" regroupe 2-1-1 et 2-1-2)
 *  - needsCitations: si vrai, le modèle doit citer des sources réelles et
 *    la section alimente la bibliographie finale
 */

const IMPETRANT_PLACEHOLDER = "[À REMPLIR PAR L'ÉTUDIANT(E) — l'agent ne peut pas inventer une dédicace personnelle]";

function splitImpetrants(studentNames) {
  return String(studentNames || "")
    .split(/[,;\n]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function buildDefaultStructure({ theme, antenne, filiere, studentNames }) {
  const lieu = antenne || "votre structure de stage";
  const impetrants = splitImpetrants(studentNames);

  return [
    { id: "titlepage", kind: "titlepage", zone: "title" },

    // ---------------------------------------------------------------
    // FRONT MATTER — pagination en chiffres romains (slide 10, 16)
    // ---------------------------------------------------------------
    { id: "toc", kind: "toc", zone: "front", title: "SOMMAIRE" },

    {
      id: "dedicaces",
      kind: "dedicaces",
      zone: "front",
      title: "DÉDICACES",
      impetrants,
      // Slide 15/49 : pas de laïus, une page par impétrant, simple énumération.
    },

    {
      id: "remerciements",
      kind: "remerciements",
      zone: "front",
      title: "REMERCIEMENTS",
      // Slide 15/18/49 : une seule page, partagée par tous les impétrants ;
      // chaque remerciement doit être justifié (à qui, et pourquoi).
      prompt:
        `Rédige une page de remerciements pour un mémoire de fin de cycle INFAS sur le thème "${theme}". ` +
        `Remercie, dans cet ordre, avec une brève justification de 1 phrase pour chacun : Dieu/la famille (motivation générale), ` +
        `le corps enseignant et administratif de l'INFAS, le directeur de mémoire, le co-directeur (s'il existe), les membres du jury, ` +
        `la structure d'accueil de stage (${lieu}), les patients/enquêtés ayant participé à l'étude, et l'entourage personnel. ` +
        `Reste bref (une page), un remerciement par paragraphe court. Utilise des espaces réservés du type ` +
        `[NOM À COMPLÉTER] pour tout nom propre que tu ne connais pas.`,
    },

    {
      id: "sigles",
      kind: "definitions",
      zone: "front",
      title: "LISTE DES ABRÉVIATIONS, SIGLES OU ACRONYMES",
      prompt:
        `Liste 5 à 10 sigles et abréviations couramment utilisés dans un mémoire INFAS sur le thème "${theme}" ` +
        `(inclure au minimum OMS, CAP si pertinent, et les sigles propres au thème). ` +
        `Réponds avec une ligne par sigle au format "SIGLE : signification complète".`,
    },

    {
      id: "liste_tableaux",
      kind: "placeholderList",
      zone: "front",
      title: "LISTE DES TABLEAUX",
      note:
        "Cette liste doit reprendre, dans l'ordre, tous les tableaux présents entre l'introduction et la conclusion " +
        "(slide 20). Elle ne peut être finalisée qu'une fois le document définitivement mis en page : à compléter " +
        "manuellement juste avant l'impression.",
    },
    {
      id: "liste_figures",
      kind: "placeholderList",
      zone: "front",
      title: "LISTE DES FIGURES",
      note:
        "Cette liste doit reprendre, dans l'ordre, toutes les figures présentes entre l'introduction et la conclusion " +
        "(slide 20). À compléter manuellement juste avant l'impression.",
    },
    {
      id: "liste_annexes",
      kind: "placeholderList",
      zone: "front",
      title: "LISTE DES ANNEXES",
      note: "À compléter manuellement une fois le contenu définitif des annexes arrêté (slide 21).",
    },

    // ---------------------------------------------------------------
    // BODY — pagination en chiffres arabes, de l'introduction aux
    // références bibliographiques incluses (slide 16)
    // ---------------------------------------------------------------
    {
      id: "introduction_intro",
      kind: "h1",
      zone: "body",
      title: "INTRODUCTION",
      headerOnly: true, // simple titre de chapitre : le contenu vient de ses sous-parties (2-1, 2-2…)
      // Pas de pageBreak explicite : c'est le premier élément de la zone
      // "body", qui démarre déjà sur une nouvelle page (nouvelle section Word).
    },

    {
      id: "enonce_probleme",
      kind: "h2",
      zone: "body",
      title: "ÉNONCÉ DU PROBLÈME",
      needsCitations: true,
      prompt:
        `Rédige, en prose continue (pas de sous-titres), l'énoncé du problème de recherche d'un mémoire INFAS sur le ` +
        `thème "${theme}", en suivant STRICTEMENT le modèle de WANDELT enseigné par l'école, dans cet ordre, sans les ` +
        `numéroter explicitement dans le texte : ` +
        `(1) une préoccupation personnelle ou une irritation observée, comme point de départ (ex: constat vécu en stage à ${lieu}) ; ` +
        `(2) les éléments de la situation : les facteurs qui causent, influencent ou entretiennent le problème ; ` +
        `(3) l'univers plus vaste dans lequel s'inscrit le problème : ce que d'autres auteurs en ont dit ou compris, avec ` +
        `des sources réelles (échelle mondiale puis africaine puis ivoirienne, en resserrant vers ${lieu}) ; ` +
        `(4) la situation désirable : à quoi ressemblerait le contexte en l'absence de ce problème ; ` +
        `(5) une ou plusieurs suggestions concrètes pour atteindre cette situation désirable, avec leurs résultats ` +
        `possibles respectifs ; ` +
        `(6) la question de recherche (ou l'hypothèse), formulée en gras à la toute fin. ` +
        `N'invente jamais de statistique, de citation ou de nom d'auteur : si une donnée réelle n'est pas disponible, ` +
        `écris un espace réservé du type [DONNÉE À VÉRIFIER] plutôt que de fabriquer un chiffre.`,
    },

    {
      id: "objectif_general",
      kind: "h2",
      zone: "body",
      title: "OBJECTIF GÉNÉRAL DE L'ÉTUDE",
      prompt: `Formule l'objectif général (intention globale visée par la recherche, une seule phrase infinitive) de l'étude sur le thème "${theme}".`,
    },
    {
      id: "objectifs_specifiques",
      kind: "h2",
      zone: "body",
      title: "OBJECTIFS SPÉCIFIQUES",
      numbered: true,
      prompt:
        `Formule 3 à 4 objectifs spécifiques (opérations/actes précis que le chercheur devra poser pour atteindre ` +
        `l'objectif général, phrases infinitives, mesurables) découlant de l'objectif général pour le thème "${theme}".`,
    },

    {
      id: "justification",
      kind: "h2",
      zone: "body",
      title: "JUSTIFICATION",
      needsCitations: true,
      subsections: ["Motivation professionnelle", "Pertinence scientifique", "Pertinence sociale"],
      prompt:
        `Rédige les trois sous-parties de la justification du choix du thème "${theme}", conformément au plan imposé ` +
        `par l'INFAS : Motivation professionnelle (motivation personnelle de l'étudiant(e), intérêt pour le sujet, ` +
        `vécu de stage à ${lieu}) ; Pertinence scientifique (EXACTEMENT 3 écrits/publications réels et vérifiés qui ` +
        `confortent le choix du sujet — utilise uniquement les sources fournies ci-dessus, cite-les au format ` +
        `Auteur-Année) ; Pertinence sociale (attentes de la population et de la structure sanitaire quant au résultat ` +
        `du travail).`,
    },

    {
      id: "definitions",
      kind: "definitions",
      zone: "body",
      title: "DÉFINITION OPÉRATIONNELLE DES TERMES",
      prompt:
        `Définis 5 à 8 termes clés du thème "${theme}" : pour chacun, uniquement le sens RETENU DANS CE TRAVAIL ` +
        `(définition opérationnelle), pas une définition générale de dictionnaire — c'est une exigence obligatoire ` +
        `de l'INFAS. Réponds avec une ligne par terme au format "Terme : sens retenu dans cette étude".`,
    },

    // ---------------------------------------------------------------
    { id: "partie1_divider", kind: "partieDivider", zone: "body", label: "PREMIÈRE PARTIE", title: "REVUE DE LA LITTÉRATURE" },
    {
      id: "partie1_intro",
      kind: "h3",
      zone: "body",
      title: "Introduction",
      prompt:
        `Rédige un court paragraphe d'introduction de la revue de littérature d'un mémoire INFAS sur "${theme}" : ` +
        `expose les thématiques à l'étude qui ont un lien avec le problème de recherche et qui unissent les textes ` +
        `choisis, en cohérence avec les objectifs spécifiques déjà formulés.`,
    },
    {
      id: "partie1_developpement",
      kind: "h3",
      zone: "body",
      title: "Développement",
      needsCitations: true,
      prompt:
        `Rédige le développement de la revue de littérature sur "${theme}", organisé par THÉMATIQUES (et non par ` +
        `zone géographique) directement liées aux objectifs spécifiques de l'étude — par exemple : généralités et ` +
        `définitions du phénomène, facteurs associés/déterminants, connaissances-attitudes-pratiques des ` +
        `professionnels de santé concernés, rôle infirmier ou sage-femme propre au thème. Pour chaque thématique, ` +
        `fais un résumé critique des textes qui s'y rapportent (regroupés par sujet), avec des sources réelles ` +
        `uniquement (celles fournies ci-dessus). N'invente aucun auteur ni chiffre.`,
    },
    {
      id: "partie1_conclusion",
      kind: "h3",
      zone: "body",
      title: "Conclusion",
      prompt:
        `Rédige la conclusion de la revue de littérature sur "${theme}" : mets les textes étudiés en perspective les ` +
        `uns par rapport aux autres et situe-les dans la problématique générale de l'étude, en amenant naturellement ` +
        `vers la deuxième partie (Notre étude).`,
    },

    // ---------------------------------------------------------------
    { id: "partie2_divider", kind: "partieDivider", zone: "body", label: "DEUXIÈME PARTIE", title: "NOTRE ÉTUDE" },

    { id: "s2_1", kind: "h2", zone: "body", numberPrefix: "2-1", title: "MATÉRIEL ET MÉTHODES", headerOnly: true },

    { id: "s2_1_1", kind: "h3", zone: "body", numberPrefix: "2-1-1", title: "MATÉRIEL", headerOnly: true },
    {
      id: "s2_1_1_1",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-1-1",
      title: "TERRAIN OU SITE DE L'ÉTUDE",
      subsections: ["Milieu de l'étude", "Cadre de l'étude", "Champ de l'étude"],
      prompt:
        `Décris le terrain/site de l'étude sur "${theme}" à ${lieu} en trois volets : Milieu de l'étude (département, ` +
        `sous-préfecture, commune, quartier, établissement public national concerné) ; Cadre de l'étude (description ` +
        `sommaire de la structure) ; Champ de l'étude (description détaillée du service concerné). Utilise ` +
        `[DONNÉE À VÉRIFIER] pour tout détail administratif précis que tu ne connais pas.`,
    },
    {
      id: "s2_1_1_2",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-1-2",
      title: "POPULATION CIBLE OU POPULATION D'ÉTUDE",
      prompt: `Définis la population cible/population d'étude pertinente pour "${theme}" à ${lieu}.`,
    },
    {
      id: "s2_1_1_3",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-1-3",
      title: "CRITÈRES DE SÉLECTION",
      subsections: ["Critères d'inclusion", "Critères de non-inclusion"],
      prompt: `Formule les critères d'inclusion et les critères de non-inclusion adaptés à l'étude de "${theme}" à ${lieu}.`,
    },

    { id: "s2_1_2", kind: "h3", zone: "body", numberPrefix: "2-1-2", title: "MÉTHODES", headerOnly: true },
    {
      id: "s2_1_2_1",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-1",
      title: "TYPE D'ÉTUDE",
      prompt: `Propose et justifie un type d'étude (le plus souvent descriptive transversale pour un mémoire INFAS) pour "${theme}".`,
    },
    {
      id: "s2_1_2_2",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-2",
      title: "PARAMÈTRES ÉTUDIÉS",
      numbered: true,
      prompt: `Liste les paramètres/variables étudiés pour répondre aux objectifs spécifiques sur "${theme}".`,
    },
    {
      id: "s2_1_2_3",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-3",
      title: "ÉCHANTILLONNAGE",
      subsections: ["Méthode", "Technique", "Taille de l'échantillon"],
      prompt:
        `Décris la méthode d'échantillonnage (exhaustive ou probabiliste), la technique utilisée, et une estimation ` +
        `de la taille de l'échantillon adaptées à l'étude de "${theme}" à ${lieu}.`,
    },
    {
      id: "s2_1_2_4",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-4",
      title: "TECHNIQUES ET OUTILS DE COLLECTE DES DONNÉES",
      prompt: `Décris les techniques et outils de collecte des données (questionnaire, grille d'observation, entretien) adaptés à "${theme}".`,
    },
    {
      id: "s2_1_2_5",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-5",
      title: "VALIDATION",
      prompt: `Décris la validation interne de l'outil de collecte et le pré-test prévu pour l'étude sur "${theme}".`,
    },
    {
      id: "s2_1_2_6",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-6",
      title: "DÉROULEMENT DE L'ENQUÊTE",
      numbered: true,
      prompt: `Décris les étapes numérotées du déroulement de l'enquête sur "${theme}" à ${lieu}.`,
    },
    {
      id: "s2_1_2_7",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-7",
      title: "TRAITEMENT ET ANALYSE DES DONNÉES",
      prompt: `Décris le traitement et l'analyse des données prévus (dépouillement manuel ou informatique, logiciel, méthode d'analyse) pour "${theme}".`,
    },
    {
      id: "s2_1_2_8",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-8",
      title: "CONSIDÉRATIONS OU ASPECTS ÉTHIQUES",
      prompt: `Rédige les considérations éthiques (consentement libre et éclairé, anonymat, confidentialité, autorisation administrative) pour une étude sur "${theme}".`,
    },
    {
      id: "s2_1_2_9",
      kind: "h4",
      zone: "body",
      numberPrefix: "2-1-2-9",
      title: "DIFFICULTÉS",
      prompt: `Anticipe les difficultés méthodologiques prévisibles pour une étude sur "${theme}" à ${lieu}.`,
    },

    {
      id: "s2_2",
      kind: "h2",
      zone: "body",
      numberPrefix: "2-2",
      title: "PRÉSENTATION DES RÉSULTATS",
      prompt:
        `Rédige une brève analyse des données attendues pour l'étude sur "${theme}" (résultats hypothétiques, ` +
        `formulés au conditionnel, avec [DONNÉE À VÉRIFIER] pour chaque valeur chiffrée — les vrais résultats ` +
        `ne pourront être rédigés qu'après l'enquête de terrain). Indique les tableaux/figures attendus par un ` +
        `repère du type [Tableau I : à insérer].`,
    },

    { id: "s2_3", kind: "h2", zone: "body", numberPrefix: "2-3", title: "DISCUSSION", headerOnly: true },
    {
      id: "s2_3_1",
      kind: "h3",
      zone: "body",
      numberPrefix: "2-3-1",
      title: "Discussion",
      needsCitations: true,
      prompt:
        `Rédige la discussion (2 à 4 pages maximum, exigence INFAS) de l'étude sur "${theme}", en suivant la ` +
        `structure imposée : (1) rappel et interprétation des principaux résultats (un paragraphe qui répond à la ` +
        `question de recherche) ; (2) comparaison des résultats avec la littérature (sources réelles fournies ` +
        `ci-dessus uniquement) ; (3) explication des écarts ou différences observés. Utilise [DONNÉE À VÉRIFIER] ` +
        `pour tout résultat chiffré, puisque l'enquête de terrain n'a pas encore été menée.`,
    },
    {
      id: "s2_3_2",
      kind: "h3",
      zone: "body",
      numberPrefix: "2-3-2",
      title: "Synthèse",
      prompt: `Rédige la synthèse de la discussion sur "${theme}" : réponds aux objectifs spécifiques de l'étude, donne les réponses clés aux préoccupations de départ.`,
    },
    {
      id: "s2_3_3",
      kind: "h3",
      zone: "body",
      numberPrefix: "2-3-3",
      title: "Limites",
      prompt: `Décris les limites de l'étude sur "${theme}" (méthodologiques, contextuelles, temporelles).`,
    },

    {
      id: "conclusion",
      kind: "h1",
      zone: "body",
      title: "CONCLUSION",
      pageBreak: true,
      prompt:
        `Rédige une conclusion (une page maximum) pour un mémoire INFAS sur "${theme}", qui : (1) répond ` +
        `explicitement à la question de recherche ; (2) donne les résultats significatifs qui y répondent ; ` +
        `(3) indique les conséquences pratiques des résultats obtenus ; (4) ouvre sur d'autres pistes de recherche.`,
    },

    {
      id: "suggestions",
      kind: "h1",
      zone: "body",
      title: "SUGGESTIONS",
      pageBreak: true,
      subsections: [
        "Suggestions à court terme (0 à 1 an)",
        "Suggestions à moyen terme (1 à 2 ans)",
        "Suggestions à long terme (2 à 3 ans)",
      ],
      prompt:
        `Rédige des suggestions concrètes découlant directement des résultats de l'étude sur "${theme}", exprimées ` +
        `à court, moyen et long terme (de 0 à 3 ans à partir de l'acceptation des travaux de recherche, exigence ` +
        `INFAS). Chaque suggestion doit indiquer concrètement ce qu'il conviendrait de faire, et avoir un lien ` +
        `direct avec les réalités révélées par l'étude à ${lieu}.`,
    },

    { id: "references", kind: "h1", zone: "body", title: "RÉFÉRENCES", pageBreak: true, isBibliography: true },

    // ---------------------------------------------------------------
    // BACK MATTER — pagination en chiffres romains, après les
    // références (slide 16 : l'arabe "prend fin aux références")
    // ---------------------------------------------------------------
    {
      id: "annexes",
      kind: "h1",
      zone: "back",
      title: "ANNEXES",
      // Pas de pageBreak explicite : premier élément de la zone "back".
      prompt:
        `Prépare un questionnaire d'enquête structuré (identification, connaissances, attitudes, pratiques) adapté ` +
        `au thème "${theme}", à joindre en annexe. Indique aussi, sous forme de liste, les autres pièces attendues ` +
        `en annexe selon l'INFAS : autorisation d'enquête, cartographie sanitaire du lieu d'étude, tout autre outil ` +
        `de collecte utilisé — avec [À JOINDRE] comme espace réservé pour chaque pièce que l'étudiant(e) doit ` +
        `fournir elle-même.`,
    },

    {
      id: "resume",
      kind: "h1",
      zone: "back",
      title: "RÉSUMÉ",
      pageBreak: true,
      subsections: ["Introduction", "Matériel et Méthodes", "Résultats significatifs", "Conclusion", "Mots clés"],
      prompt:
        `Rédige le résumé du mémoire sur "${theme}" en 5 parties courtes, format imposé par l'INFAS (à placer aussi ` +
        `au verso de la dernière page) : Introduction (présentation du sujet, son intérêt, l'objectif général) ; ` +
        `Matériel et Méthodes (terrain, méthode, échantillon, instruments) ; Résultats significatifs (au ` +
        `conditionnel avec [DONNÉE À VÉRIFIER], l'enquête n'ayant pas encore été menée) ; Conclusion (ouverture de ` +
        `l'analyse) ; Mots clés (5 à 6 mots-clés séparés par des virgules).`,
    },
  ];
}

module.exports = { buildDefaultStructure, splitImpetrants, IMPETRANT_PLACEHOLDER };

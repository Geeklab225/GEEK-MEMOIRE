# GEEKLAB

Application web (nom de code **GEEKLAB**) permettant à des étudiant(e)s INFAS
(infirmiers, sages-femmes, etc.) de générer un mémoire de fin de cycle complet
(.docx) à partir d'un simple thème : introduction, objectifs, justification,
revue de littérature, méthodologie, résultats attendus, conclusion,
bibliographie et annexes — selon la méthodologie officielle INFAS.

## ⚠️ État actuel — ce qui manque avant une vraie mise en production

1. **Méthodologie officielle INFAS implémentée.** `generator/structure.js`
   suit maintenant fidèlement le support méthodologique officiel fourni par
   l'école (« Rédaction Mémo 2024 IDE3 SFM3 ABG », 54 diapositives, antenne
   d'Abengourou) : plan complet (sommaire → dédicaces → remerciements →
   listes → introduction selon le modèle de WANDELT → revue de littérature
   thématique → étude avec la numérotation exacte 2-1 / 2-1-1 / 2-1-1-1… →
   conclusion → suggestions → références → annexes → résumé), citations
   Auteur-Année **sans numéro entre crochets** (l'INFAS déconseille
   explicitement le "système numérique séquentiel"), bibliographie
   alphabétique ("alpha-numérique", 6 premiers auteurs en toutes lettres),
   page de garde avec jury complet et numéro de mémoire, dédicaces (une page
   par impétrant, sans laïus), pagination romaine/arabe/romaine, mise en
   page Times New Roman 14 / interligne 1,5 / marges et encadré orange
   imposés. Voir "Hypothèses retenues" ci-dessous pour les quelques points
   que le support ne précisait pas explicitement.
2. **Aucune clé API IA n'est configurée par défaut.** Sans clé, l'application
   fonctionne intégralement (comptes, formulaire, génération du .docx) mais
   chaque section contient un texte "espace réservé" au lieu du contenu
   rédigé. Voir "Connecter une clé API" ci-dessous.
3. **Recherche documentaire réelle intégrée, mais non testée en conditions
   réelles.** `generator/research.js` interroge PubMed, CrossRef et
   OpenAlex pour trouver de vraies sources (auteurs, année, DOI) et remplit
   automatiquement la bibliographie — voir la section "Recherche
   documentaire" ci-dessous pour ce qui est couvert, ce qui ne l'est pas
   encore, et une limite importante : **le réseau sortant de l'environnement
   où j'ai développé cet agent est restreint** (liste blanche de domaines),
   ce qui m'a empêché d'appeler les vraies APIs pendant le développement (je
   l'ai reconfirmé en créant un mémoire test de bout en bout : les 3 APIs
   ont bien renvoyé une erreur 403 "Host not in [allowlist]"). J'ai donc
   testé toute la logique avec des réponses API simulées
   (`generator/research.test.js`, `generator/pipeline.test.js` — tous les
   tests passent), mais **le tout premier appel réseau réel doit être
   vérifié par vous**, une fois l'application lancée sur votre machine ou
   déployée en ligne (un réseau normal, sans restriction).
4. **Pas encore déployé en ligne.** L'application tourne pour l'instant en
   local dans cet environnement de développement. Voir "Déploiement" plus
   bas pour la mettre en ligne pour plusieurs étudiants.

## Hypothèses retenues (points que le support méthodologique ne précisait pas)

Le support fourni est très complet mais laisse quelques détails d'implémentation
ouverts. Voici les choix faits, à corriger vous-même si votre école les
tranche différemment :

- **Pagination des annexes/résumé** : le support précise que la pagination
  arabe "prend fin aux références bibliographiques" (slide 16), ce qui
  implique un retour aux chiffres romains pour les annexes et le résumé,
  mais ne dit pas si cette numérotation romaine repart de "i" ou continue
  depuis le sommaire/dédicaces. J'ai choisi de la faire **continuer** (le
  compteur de pages continue d'augmenter, seul l'affichage change de format)
  plutôt que de la faire repartir de "i", pour éviter deux pages différentes
  portant le même numéro dans le document. Si votre école attend un
  redémarrage à "i", changez `NumberFormat.LOWER_ROMAN` en ajoutant un
  `start: 1` dans la 4ᵉ section de `generator/docxBuilder.js` (`build()`).
- **Logo INFAS** : je n'ai pas le fichier image du logo ; la page de garde
  affiche un espace réservé texte `[LOGO INFAS]`. Remplacez-le par une vraie
  image dans `buildTitlePage()` (`generator/docxBuilder.js`) si vous
  fournissez le fichier logo.
- **Dates de mise à jour des fiches OMS** : `WHO_FACT_SHEETS`
  (`generator/research.js`) n'a pas de date figée pour chaque fiche (les
  fiches OMS sont révisées périodiquement) — l'agent écrit "s.d." tant que
  vous n'avez pas renseigné vous-même le champ `year` de la fiche concernée.
- **Nom des impétrants sur la page de garde/dédicaces** : l'agent affiche le
  nom tel que saisi dans le formulaire, sans le reformater — c'est à
  l'étudiant(e) de respecter la convention INFAS (NOM en MAJUSCULES,
  Prénoms avec 1ère lettre en majuscule, slide 14).
- **Contenu des dédicaces** : le support demande une simple énumération des
  personnes (pas de prose), mais l'agent ne peut évidemment pas savoir à qui
  chaque étudiant(e) souhaite dédier son travail : chaque page de dédicace
  contient des espaces réservés `[NOM DE LA PERSONNE… À COMPLÉTER]` à remplir
  soi-même.

## Stack technique

- **Backend** : Node.js + Express
- **Base de données** : SQLite (`better-sqlite3`) — un fichier local,
  suffisant pour démarrer ; migration vers PostgreSQL recommandée au-delà de
  quelques dizaines d'utilisateurs simultanés.
- **Comptes** : sessions Express + mots de passe hashés (`bcryptjs`)
- **Génération Word** : `docx` (docx-js), même approche que les mémoires
  produits précédemment dans nos échanges (page de garde, table des
  matières, pages "Partie" encadrées, en-tête/pied de page)
- **Génération de contenu** : appel à l'API Messages d'Anthropic (Claude),
  avec repli automatique sur un texte "espace réservé" si aucune clé n'est
  configurée

## Installation locale

```bash
npm install
cp .env.example .env
# éditez .env : ajoutez votre ANTHROPIC_API_KEY si vous en avez une
npm start
```

L'application est alors disponible sur http://localhost:3000.

## Recherche documentaire (PubMed, CrossRef, OpenAlex, OMS)

Avant de rédiger l'introduction, la justification et la revue de
littérature, l'agent interroge maintenant de vraies bases bibliographiques
pour trouver des sources réellement vérifiables, au lieu de laisser le
modèle de langage inventer des auteurs ou des chiffres. C'est le module
`generator/research.js`.

**Ce qui est couvert, sans clé API, gratuitement :**

- **PubMed** (NCBI E-utilities) — littérature biomédicale et infirmière ;
  couvre bien les études de type CAP (connaissances, attitudes, pratiques)
- **CrossRef** — métadonnées DOI toutes disciplines, bonne couverture
  générale des revues
- **OpenAlex** — base ouverte utilisée comme filet de secours
- **OMS** — une petite liste organisée (`WHO_FACT_SHEETS` dans
  `research.js`) associe des mots-clés à des fiches d'information OMS
  stables et vérifiées. **À enrichir manuellement** : l'OMS n'a pas d'API
  de recherche publique, donc chaque nouveau thème nécessite d'ajouter la
  bonne URL de fiche à la main (ou de laisser le champ vide : l'agent
  continuera avec PubMed/CrossRef/OpenAlex uniquement).

**Ce qui N'EST PAS encore couvert**, et nécessiterait une clé de recherche
web payante (Tavily, Bing Search API, SerpAPI, Google Custom Search, etc.)
pour un vrai "parcours du web" au sens large :

- Mémoires et thèses en ligne (African Journals Online, DUMAS, bibliothèques
  d'instituts de formation ivoiriens, etc.)
- Littérature grise (rapports ministériels, directives PNTS-CI, etc.)
- Pages web générales hors bases bibliographiques structurées

Si vous voulez cette couverture plus large, dites-le-moi et j'ajouterai un
point d'intégration pour l'un de ces services (le code est déjà organisé
pour qu'ajouter une quatrième source dans `research.js` soit simple — même
motif que PubMed/CrossRef/OpenAlex).

**Comment ça s'articule avec la génération :** pour chaque nouveau mémoire,
`generateMemoire()` (dans `pipeline.js`) appelle une seule fois
`research.gatherSources(theme)`, construit une liste de sources réelles
numérotées, et : (a) injecte cette liste dans le prompt de chaque section
marquée `needsCitations: true` dans `structure.js`, avec l'instruction
stricte de n'utiliser QUE ces sources ; (b) remplit directement la section
"Références bibliographiques" du .docx à partir de cette même liste — sans
passer par le modèle de langage, pour éliminer tout risque d'invention à
cette étape précise.

**Vérifier que ça fonctionne réellement :**

```bash
node generator/research.test.js    # teste le parsing de chaque API (réponses simulées)
node generator/pipeline.test.js    # teste le pipeline complet de bout en bout
```

Ces deux commandes passent dans cet environnement de développement (réseau
simulé). **Pour un vrai test avec le réseau réel**, créez un mémoire depuis
l'interface (`/memoires/new`) une fois l'application lancée sur une machine
avec accès internet normal, puis ouvrez le .docx généré et vérifiez que la
bibliographie contient de vraies références (avec un vrai DOI/PMID qui
résout correctement).

## Connecter une clé API Claude

1. Créez une clé sur https://console.anthropic.com
2. Ouvrez `.env` et renseignez :
   ```
   ANTHROPIC_API_KEY=sk-ant-...
   ```
3. Redémarrez le serveur (`npm start`). Les prochains mémoires générés
   contiendront le texte rédigé par l'IA à la place des espaces réservés.

Aucune autre modification de code n'est nécessaire — `generator/llm.js`
détecte automatiquement la présence de la clé.

## Structure du projet

```
server.js               Point d'entrée Express
db/schema.sql            Schéma SQLite (users, memoires)
db/db.js                  Connexion + application du schéma au démarrage
routes/auth.js            Inscription / connexion / déconnexion
routes/memoires.js        Création, consultation, téléchargement des mémoires
generator/structure.js    Plan du mémoire — conforme au guide méthodologique officiel INFAS
generator/antennes.js     Table des codes d'antenne + calcul du numéro de mémoire (ex: N° 017SFM-26ABG)
generator/research.js     Recherche PubMed / CrossRef / OpenAlex / OMS — sources réelles vérifiées
generator/research.test.js   Tests du parsing des 3 APIs + du format de citation INFAS (réponses simulées)
generator/llm.js          Appel au modèle IA (ou placeholder si pas de clé)
generator/docxBuilder.js  Mise en forme Word (page de garde, jury, pagination romaine/arabe, styles)
generator/pipeline.js     Orchestration : recherche → génération → .docx
generator/pipeline.test.js   Test d'intégration du pipeline complet (réseau simulé)
views/                    Pages EJS (inscription, connexion, tableau de bord, formulaire, détail)
public/style.css          Feuille de style
generated/                Fichiers .docx produits (ignoré par git)
```

## Adapter la méthodologie si votre antenne a des consignes différentes

`generator/structure.js` reflète le support fourni par l'antenne
d'Abengourou (IDE3/SFM3, 2024). Si votre antenne applique des variantes,
ouvrez `generator/structure.js` et ajustez la fonction
`buildDefaultStructure()` :

- Ajoutez/retirez des sections (ex: une section "Hypothèses" si l'école
  l'exige)
- Changez l'ordre des parties ou la numérotation manuelle (`numberPrefix`)
  si nécessaire
- Ajustez le `prompt` de chaque section pour refléter les consignes exactes
  (nombre de pages attendu, etc.)
- Le moteur de mise en page (`generator/docxBuilder.js`) lit dynamiquement
  la structure fournie (zones `front`/`body`/`back`, `kind`, `numberPrefix`,
  `subsections`, `headerOnly`…) — il n'a normalement pas besoin d'être
  modifié pour ce genre d'ajustement.

## Déploiement en ligne — domaine geeklab-ci.online

L'application est prête pour un déploiement (fichiers `Dockerfile`,
`railway.toml`, `render.yaml`, `Procfile` inclus). Trois options, de la plus
simple à la plus contrôlée :

### Option A — Railway (recommandé pour démarrer)

1. Poussez ce dossier vers un dépôt GitHub (voir "Mettre le code sur
   GitHub" ci-dessous si ce n'est pas déjà fait).
2. Sur [railway.app](https://railway.app) : **New Project → Deploy from
   GitHub repo** → sélectionnez le dépôt. Railway détecte Node.js
   automatiquement (`railway.toml` précise juste la commande de démarrage).
3. Onglet **Variables** du service, ajoutez :
   - `SESSION_SECRET` → une valeur aléatoire longue (générez-la avec
     `openssl rand -hex 32` sur votre machine, ou laissez Railway en générer
     une)
   - `NODE_ENV` → `production`
   - `ANTHROPIC_API_KEY` → dès que vous l'avez (facultatif au démarrage)
   - `RESEARCH_CONTACT_EMAIL` → votre email de contact (recommandé, voir
     plus haut)
4. Onglet **Volumes** : ajoutez un volume monté sur `/app/db`. **Sans cette
   étape, la base de données (comptes, mémoires) est effacée à chaque
   redéploiement** — c'est le point le plus facile à oublier.
5. Onglet **Settings → Networking → Custom Domain** : ajoutez
   `geeklab-ci.online` (et/ou `www.geeklab-ci.online`). Railway affiche alors
   une valeur CNAME à créer chez votre registraire de domaine (celui où vous
   avez acheté `geeklab-ci.online`) :
   - Chez le registraire, section DNS : créez un enregistrement `CNAME` pour
     `www` pointant vers la valeur donnée par Railway.
   - Pour le domaine "nu" (`geeklab-ci.online` sans `www`), la plupart des
     registraires n'acceptent pas de CNAME à la racine : utilisez
     l'enregistrement `ALIAS`/`ANAME` s'il est proposé, ou redirigez
     `geeklab-ci.online` → `www.geeklab-ci.online`, ou passez le domaine chez
     Cloudflare (gratuit) qui gère ce cas nativement.
   - Le certificat HTTPS est généré automatiquement par Railway une fois le
     DNS propagé (quelques minutes à quelques heures).

### Option B — Render

Même principe : **New → Blueprint**, sélectionnez le dépôt, Render lit
`render.yaml` (service web + disque persistant pour la base SQLite déjà
configurés). Ajoutez `ANTHROPIC_API_KEY` manuellement dans l'onglet
Environment une fois disponible. Pour le domaine, **Settings → Custom
Domain** fonctionne de la même façon que Railway (CNAME `www`, gérer la
racine via Cloudflare/ALIAS).

### Option C — VPS (serveur Ubuntu, avec Docker)

```bash
git clone <votre-dépôt> geeklab && cd geeklab
cp .env.example .env   # puis éditez .env (SESSION_SECRET, etc.)
docker build -t geeklab .
docker run -d --name geeklab \
  --restart unless-stopped \
  -p 3000:3000 \
  --env-file .env \
  -e NODE_ENV=production \
  -v geeklab_db:/app/db \
  -v geeklab_generated:/app/generated \
  geeklab
```

Puis un reverse proxy Nginx + certificat HTTPS (Let's Encrypt / `certbot`)
devant le port 3000, avec `geeklab-ci.online` en `server_name` et un
enregistrement DNS de type `A` chez votre registraire pointant vers l'IP du
VPS.

### Mettre le code sur GitHub (si pas encore fait)

```bash
cd infas_agent   # dossier décompressé de l'archive livrée
git init
git add .
git commit -m "GEEKLAB — première version"
git branch -M main
git remote add origin <URL-de-votre-dépôt-GitHub>
git push -u origin main
```

Envoyez-moi ensuite le lien de votre dépôt : je pourrai vérifier que tout
est cohérent (fichiers de config, `.gitignore`) et ajuster si besoin.

### Points de sécurité déjà en place / à surveiller

- ✅ `SESSION_SECRET` doit être remplacé par une valeur aléatoire longue en
  production (`openssl rand -hex 32`) — ne gardez jamais la valeur par
  défaut du code en ligne.
- ✅ Le cookie de session passe automatiquement en `secure: true` (HTTPS
  uniquement) dès que `NODE_ENV=production` est défini (déjà géré dans
  `server.js`).
- ⚠️ **Base de données** : SQLite convient pour démarrer, mais nécessite un
  volume persistant (voir ci-dessus) et ne encaisse pas bien de très
  nombreux étudiants simultanés. Migrez vers PostgreSQL au-delà de quelques
  dizaines d'utilisateurs actifs en même temps.
- ⚠️ **Coûts API IA** : une fois `ANTHROPIC_API_KEY` configurée, chaque
  mémoire généré consomme des appels API payants. Envisagez une limite de
  débit (rate limiting) sur la création de mémoires si l'usage grandit.
- ⚠️ **File de génération** : chaque génération tourne immédiatement en
  arrière-plan dans le même processus — correct pour un usage restreint
  (quelques dizaines d'étudiants), à revoir (file d'attente type BullMQ) si
  l'usage grandit fortement.
- ⚠️ **Sessions en mémoire** : `express-session` avertit au démarrage que le
  stockage par défaut ("MemoryStore") ne convient pas à la production — les
  sessions sont perdues à chaque redémarrage du serveur et ne fonctionnent
  pas si vous faites tourner plusieurs instances en parallèle. Pour une
  antenne (quelques dizaines d'étudiants), c'est un inconvénient mineur ;
  si ça devient gênant, remplacez par `connect-sqlite3` (simple, cohérent
  avec la base déjà utilisée) ou un store Redis.

## Prochaines étapes suggérées

1. Lancer l'application sur une machine avec accès internet normal et créer
   un mémoire test, pour confirmer que la recherche PubMed/CrossRef/OpenAlex
   fonctionne réellement (voir "Recherche documentaire" ci-dessus) — c'est
   le test que je n'ai pas pu faire moi-même à cause des restrictions
   réseau de mon environnement de développement.
2. Obtenir une clé API Anthropic et me confirmer quand elle est prête, pour
   tester la génération de contenu réel.
3. Me dire si vous voulez élargir la recherche aux mémoires en ligne et à la
   littérature grise (nécessite une clé de recherche web payante — voir
   "Recherche documentaire" ci-dessus).
4. Décider d'un hébergeur pour la mise en ligne (je peux préparer la
   configuration de déploiement dès que ce choix est fait).
5. Relire une page de garde générée et me signaler tout écart avec les
   consignes exactes de votre antenne (composition du jury, numéro de
   mémoire) — voir "Hypothèses retenues" ci-dessus pour les points que le
   support ne précisait pas.
